""" TO-DO List:
1. Check for unused variables
2. Create the code for commands to change the site manually
3. Test the updates """

#---------------------------------------
# Import Libraries
#---------------------------------------
import sys
import os
import codecs
import json
import time
import collections
sys.path.append(os.path.join(os.path.dirname(__file__), "Classes"))
import clr
clr.AddReference("IronPython.SQLite.dll")
clr.AddReference("IronPython.Modules.dll")
from SettingsClass import Settings
from collections import OrderedDict

#---------------------------------------
# Script Information
#---------------------------------------
ScriptName = "Multi-Streaming Utility"
Website = "https://rebrand.ly/vonWebsite "
Description = "Multi-Streaming utility for your stream."
Creator = "von_Schappler"
Version = "1.2.0"

#---------------------------------------
# Variables
#---------------------------------------
global settingsFile, scriptSettings, logoDir
global casterName, dispName, url, friends, game, multiMsgToSend, isEnabled, directory
global logFileName, gameToShow, gameSet, fileSaved, printLog, autoLog, logMessage
global providersList, providersName, providersRef, providersLink, friendsSet, urlSet, multiOn
global multiMsg, multiFriends, multiProvider, multiCustom, multiGame, setMultiOn, setMultiOff
global setMultiGame, setMultiProvider, multiDisplay, multiUserCD, multiAutoCD, multiAutoMsg
global printLog, autoLog
settingsFile = os.path.join(os.path.dirname(__file__), "settings.json")
providersFile = os.path.join(os.path.dirname(__file__), "providers.json")
uiFile = os.path.join(os.path.dirname(__file__), "UI_Config.json")
logDir = os.path.join(os.path.dirname(__file__), "Log")
scriptSettings = Settings(settingsFile)
isEnabled = True
multiMsg = "/me : {caster} is currently Multi-Streaming with {friends} at {link} ! Click the link to a multi-view of {game}!"
multiFriends = "caster1"
multiProvider = "MultiTwitch_LIVE(id=1)"
multiCustom = "example.provider"
multiGame = "auto"
setMultiOn = "!setmultion"
setMultiOff = "!setmultioff"
setMultiGame = "!setmultigame"
setMultiProvider = "!setmultisite"
multiDisplay = "!multi"
multiUserCD = 5.0
multiAutoMsg = True
multiAutoCD = 10
printLog = False
autoLog = True
friends = ""
friendsSet = False
url = ""
urlSet = False
multiMsgToSend = ""
logFileName = "MultiStreamLog_"
gameToShow = ""
gameSet = False
fileSaved = False
providersName = []
providersRef = []
providersLink = []
multiOn = False

#---------------------------------------
# Initialize Data on Load
#---------------------------------------
def Init():
	global providersList, friends, multiMsgToSend, multiOn, casterName, selProvider, friendsList, game
	casterName = Parent.GetChannelName()
	if not os.path.exists(logDir):
		os.makedirs(logDir)
	try:
		with codecs.open(settingsFile, encoding="utf-8-sig", mode="r") as f:
			ReloadSettings(f.read())
	except:
		Parent.Log("ERROR: ", "[" + ScriptName + "]:  Unable to load settings during execution! (Init)")
	with codecs.open(providersFile, encoding="utf-8-sig", mode="r") as f:
		providersList = json.load(f, encoding="utf-8")
		for item in providersList['providers']:
			providersName.append(item['name'])
			providersRef.append(item['cmdref'])
			providersLink.append(item['url'])
	with codecs.open(uiFile, encoding="utf-8-sig", mode="r") as f:
		data = json.load(f, encoding="utf-8", object_pairs_hook=OrderedDict)
	data['multiProvider']['items'] = providersName
	data['multiProvider']['value'] = providersName[0]
	friends = multiFriends
	with codecs.open(uiFile, encoding="utf-8-sig", mode="w+") as f:
		json.dump(data, f, encoding="utf-8", indent=2)

	try:
		if (open(settingsFile)):
			if friendsSet == False and scriptSettings.multiFriends != "":
				friendsList = scriptSettings.multiFriends
				SetFriends(friendsList)
			if urlSet == False:
				selProvider = providersLink[int(providersName.index(scriptSettings.multiProvider))]
				if selProvider == "custom":
					if multiCustom == "" or multiCustom == "example.provider":
						selProvider = providersLink[1]
						Parent.SendStreamWhisper(casterName,"/me : [" + ScriptName + "]: You chose to use a custom provider but haven't defined one. The link created will redirect to the default script provider: \"" + selProvider +"\". ")
				elif multiCustom != "" or multiCustom != "example.provider":
					selProvider = multiCustom
				SetUrl(selProvider)
			if gameSet == False:
				game = scriptSettings.multiGame
				SetGame(game)
			if friendsSet and urlSet and gameSet:
				multiMsgToSend = scriptSettings.multiMsg.format(caster = casterName, link = url[:-1], friends = friends[:-1], game = gameToShow)
				Parent.SendStreamWhisper(casterName, "/me : [" + ScriptName + "]: Multi-Stream link was created automatically using last saved UI settings. Type !setmultion to start the script with the loaded settings. (Link created: " + url + ")")
			elif not friendsSet or not urlSet or not gameSet:
				Parent.SendStreamWhisper(casterName, "/me : [" + ScriptName + "]: Unable to create Multi-Stream link using last saved UI settings. Use the specified command with correct values to create a link manually.")
			return multiOn
	except:
		Parent.SendStreamWhisper(casterName, "/me : [" + ScriptName + "]: Welcome! This is your first time using this script. To ensure its funcionalities, open the script UI and press \"Save Settings\"...")
	

#---------------------------
#   [Optional] Reload Settings (Called when a user clicks the Save Settings button in the Chatbot UI)
#---------------------------
def ReloadSettings(jsondata):
	global logFileName, logMessage, printLog, autoLog, multiCustom, friendsList, friendsSet, url, urlSet, gameSet, multiOn, multiMsgToSend
	scriptSettings.Reload(jsondata)
	casterName = Parent.GetChannelName()
	friendsList = ""
	url = ""
	friendsSet = False
	urlSet = False
	gameSet = False
	multiMsg = scriptSettings.multiMsg
	multiFriends = scriptSettings.multiFriends
	multiProvider = scriptSettings.multiProvider
	multiCustom = scriptSettings.multiCustom
	multiGame = scriptSettings.multiGame
	setMultiOn = scriptSettings.setMultiOn
	setMultiOff = scriptSettings.setMultiOff
	setMultiGame = scriptSettings.setMultiGame
	setMultiProvider = scriptSettings.setMultiProvider
	multiDisplay = scriptSettings.multiDisplay
	multiUserCD = scriptSettings.multiUserCD
	multiAutoMsg = scriptSettings.multiAutoMsg
	multiAutoCD = scriptSettings.multiAutoCD
	printLog = scriptSettings.printLog
	autoLog = scriptSettings.autoLog
	logFileName += time.strftime("%Y%m%d_%H%M%S") + ".log"
	logMessage = time.strftime("[%Y/%m/%d@%H:%M:%S]") + " This is the begin of the Log data for " + ScriptName + ":\n"
	logMessage += "=========\n"
	logMessage += "Last saved settings:\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Message to sent in chat with Multi-Streaming link: " + str(multiMsg) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Last UI saved friends: " + str(multiFriends) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Preferred Multi-Streaming provider: " + str(multiProvider) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Custom Multi-Streaming provider: " + str(multiCustom) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Game played during Multi-Streaming: " + str(multiGame) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Command to set link for Multi-Streaming: " + str(setMultiOn) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Command to reset link for Multi-Streaming: " + str(setMultiOff) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Command to set game manually: " + str(setMultiGame) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Command to set Multi-Stream site manually: " + str(setMultiProvider) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Command to display Multi-Streaming link in chat: " + str(multiDisplay) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: User cooldown between uses of Multi-Streaming display command: " + str(multiUserCD) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Allow the script to auto post Multi-Stream link: " + str(multiAutoMsg) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Time between auto Multi-Streaming Messages: " + str(multiAutoCD) + "\n"
	logMessage += "=========\n"
	if printLog == True:
		Parent.Log("INFO: ", time.strftime("(%Y/%m/%d - %H:%M:%S) ") + ScriptName + " last saved settings:")
		Parent.Log("SETTINGS: ", "[" + ScriptName + "]: Message to sent in chat with Multi-Streaming link: " + str(multiMsg))
		Parent.Log("SETTINGS: ", "[" + ScriptName + "]: Last UI saved friends: " + str(multiFriends))
		Parent.Log("SETTINGS: ", "[" + ScriptName + "]: Preferred Multi-Streaming provider: " + str(multiProvider))
		Parent.Log("SETTINGS: ", "[" + ScriptName + "]: Custom Multi-Streaming provider: " + str(multiCustom))
		Parent.Log("SETTINGS: ", "[" + ScriptName + "]: Game played during Multi-Streaming: " + str(multiGame))
		Parent.Log("SETTINGS: ", "[" + ScriptName + "]: Command to set link for Multi-Streaming: " + str(setMultiOn))
		Parent.Log("SETTINGS: ", "[" + ScriptName + "]: Command to reset link for Multi-Streaming: " + str(setMultiOff))
		Parent.Log("SETTINGS: ", "[" + ScriptName + "]: Command to set game manually: " + str(setMultiGame))
		Parent.Log("SETTINGS: ", "[" + ScriptName + "]: Command to set Multi-Stream site manually: " + str(setMultiProvider))
		Parent.Log("SETTINGS: ", "[" + ScriptName + "]: Command to display Multi-Streaming link in chat: " + str(multiDisplay))
		Parent.Log("SETTINGS: ", "[" + ScriptName + "]: User cooldown between uses of Multi-Streaming display command: " + str(multiUserCD))
		Parent.Log("SETTINGS: ", "[" + ScriptName + "]: Allow the script to auto post Multi-Stream link: " + str(multiAutoMsg))
		Parent.Log("SETTINGS: ", "[" + ScriptName + "]: Time between auto Multi-Streaming Messages: " + str(multiAutoCD))
	
	friendsList = scriptSettings.multiFriends
	SetFriends(friendsList)
	selProvider = providersLink[int(providersName.index(scriptSettings.multiProvider))]
	if selProvider == "custom":
		if multiCustom == "" or multiCustom == "example.provider":
			selProvider = providersLink[1]
			Parent.SendStreamWhisper(casterName,"/me : [" + ScriptName + "]: You chose to use a custom provider but haven't defined one. The link created will redirect to the default script provider: \"" + selProvider +"\". ")
		elif multiCustom != "" or multiCustom != "example.provider":
			selProvider = multiCustom
	SetUrl(selProvider)
	game = scriptSettings.multiGame
	SetGame(game)
	multiMsgToSend = scriptSettings.multiMsg.format(caster = casterName, link = url[:-1], friends = friends[:-1], game = gameToShow)
	Parent.SendStreamWhisper(casterName, "/me : [" + ScriptName + "]: Multi-Streaming url was created or updated after saving UI settings. (Link created: " + url + ")")
	return multiMsgToSend

#---------------------------------------
#	Script is going to be unloaded
#---------------------------------------
def Unload():
	scriptSettings.Save(settingsFile)
	if not fileSaved and autoLog:
		LogFile()
	return

#---------------------------------------
#	Script is enabled or disabled on UI
#---------------------------------------
def ScriptToggled(state):
	global scriptSettings, isEnabled
	if not state:
		scriptSettings.Save(settingsFile)
		isEnabled = False
	else:
		isEnabled = True
	return isEnabled

#---------------------------------------
# Execute data and process messages
#---------------------------------------
def Execute(data):
	if data.IsChatMessage() and isEnabled:
		if data.IsFromTwitch():
			source = "twitch"
			Multi(source, data.User.lower(), data.GetParam(0), data.Message[len(data.GetParam(0)) + len(" "):])
		if data.IsFromDiscord():
			source = "discord"
			Multi(source, data.User.lower(), data.GetParam(0), data.Message[len(data.GetParam(0)) + len(" "):])
	return

#---------------------------------------
# Tick
#---------------------------------------
def Tick():
	global logMessage
	multiAutoCD = scriptSettings.multiAutoCD
	multiAutoMsg = scriptSettings.multiAutoMsg
	if multiAutoMsg and not Parent.IsOnCooldown(ScriptName, "autoMulti") and Parent.IsLive() and multiOn:
		cd = multiAutoCD * 60
		Parent.SendStreamMessage(multiMsgToSend)
		logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: the Multi-Stream link was displayed in chat automatically\n"
		if printLog == True:
			Parent.Log("INFO: ", "[" + ScriptName + "]: Multi-Stream link was displayed in chat automatically")
		Parent.AddCooldown(ScriptName, "autoMulti", cd)
	return

#---------------------------------------
# Functions
#---------------------------------------
def Multi(source, user, message, args):
	global selProvider, coolDown, command, casterName, url, friends, multiMsgToSend, logMessage, gameToShow, gameSet, friendsSet, multiOn, friendsList, game, selProvider
	coolDown = scriptSettings.multiUserCD * 60
	globalCD = 10
	command = message
	setCommands = [scriptSettings.setMultiOn, scriptSettings.setMultiOff, scriptSettings.setMultiGame, scriptSettings.setMultiProvider]
	showCommand = [scriptSettings.multiDisplay]
	casterName = Parent.GetChannelName()
	source = source
	friendsList = scriptSettings.multiFriends
	selProvider = providersLink[int(providersName.index(scriptSettings.multiProvider))]
	game = scriptSettings.multiGame
	if Parent.HasPermission(user, "Moderator", ""):
		if command == setCommands[0]:
			if friendsSet and gameSet and urlSet:
				multiMsgToSend = scriptSettings.multiMsg.format(caster = casterName, link = url[:-1], friends = friends[:-1], game = gameToShow)
				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + "to create a Multi-Stream link\n"
				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: Multi-Stream link was created by " + user + " with success using UI saved parameters\n"
				if printLog == True:
					Parent.Log("INFO:", "[" + ScriptName + "]: Multi-Stream link was created by " + user + " with success using UI saved parameters")
				multiOn = True
			if (friendsSet and args != "") or (not friendsSet and args != ""):
				multiMsgToSend = ""
				SetFriends(args)
				SetUrl(selProvider)
				multiMsgToSend = scriptSettings.multiMsg.format(caster = casterName, link = url[:-1], friends = friends[:-1], game = gameToShow)
				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + " to change casters to " + args + "\n"
				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: " + user + " changed casters with success\n"
				if printLog == True:
					Parent.Log("INFO:", "[" + ScriptName + "]: " + user + " changed casters with success to " + friends)
				multiOn = True
			if (friendsSet and args == ""):
				if friendsList != "":
					Parent.SendStreamWhisper(user, "/me : [" + ScriptName + "]: no changes were made to previous created link because you didn't entered new arguments.")
					logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + " to change casters to " + args + "\n"
					logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: no changes were made to previous created link. \n"
					if printLog == True:
						Parent.Log("INFO:", "[" + ScriptName + "]: no changes weer made to previous created link.")
				elif friendsList == "":
					logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + " to change casters to " + args + "\n"
					logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR: " + user + " failed to add or update casters. Previous message was not changed. (Reason: Missing arguments)\n"
					if printLog == True:
						Parent.Log("ERROR:", "[" + ScriptName + "]: " + user + " failed to add or update casters. (Reason: Missing argurments)")
				multiOn = True
			elif not friendsList and args == "":
				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + " to change casters to " + args + "\n"
				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR: " + user + " failed to create Multi-Stream link.(Reason: Missing arguments)\n"
				if printLog == True:
					Parent.Log("ERROR:", "[" + ScriptName + "]: " + user + " failed to create Multi-Stream link. (Reason: Missing argurments)")
				multiOn = False
			if multiOn == True:
				Parent.SendStreamWhisper(user, "/me : [" + ScriptName + "]: Multi-Stream link is set correctly. Viewers can now type !multi in chat to display this link: " + url + " where " + casterName + " is playing " + gameToShow)
			elif multiOn == False:
				Parent.SendStreamWhisper(user, "/me : [" + ScriptName + "]: Failed to create or update Multi-Stream link. Required info to create the link was not given. Type " + command + " followed by the names of casters to create the Multi-Stream link, separated by a blank space, e.g.: " + command + " caster1 caster 2")
		if command == setCommands[1]:
			multiMsgToSend = ""
			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + " to disable Multi-Stream link\n"
			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: " + user + " has disabled Multi-Stream link\n"
			if printLog == True:
				Parent.Log("INFO:", "[" + ScriptName + "]: " + user + " has disabled Multi-Stream link")
			multiOn = False
			Parent.SendStreamWhisper(user, "/me : [" + ScriptName + "]: Multi-Stream link was disabled")
		if command == setCommands[2]:
			SetGame(args)
			multiMsgToSend = scriptSettings.multiMsg.format(caster = casterName, link = url[:-1], friends = friends[:-1], game = gameToShow)
			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + " to edit game to " + gameToShow + "\n"
			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: " + user + " has changed the game with success\n"
			if printLog == True:
				Parent.Log("INFO:", "[" + ScriptName + "]: "+ user + " has changed the game with success to " + gameToShow)
			Parent.SendStreamWhisper(user, "/me : [" + ScriptName + "]: Game was changed to "+ gameToShow)
		if command == setCommands[3]:
			entry = args.split(" ")
			if entry[0] in providersRef:
				if entry[0] == "0":
					if len(entry) == 1:
						selProvider = providersLink[1]
						Parent.SendStreamWhisper(user, "/me : [" + ScriptName + "]: Because there is no custom provider set and you haven't entered any with this command, the link will be redirected to the last saved provider: \"" + selProvider + "\".")
					elif len(entry) == 2:
						selProvider = entry[1]
					elif len(entry) > 2:
						Parent.SendStreamWhisper(user, "/me [" + ScriptName + "]: Failed to change Multi-Stream link. (Reason: Too many parameters)")
				else:
					selProvider = providersLink[int(entry[0])]
				SetUrl(selProvider)
				multiMsgToSend = scriptSettings.multiMsg.format(caster = casterName, link = url[:-1], friends = friends[:-1], game = gameToShow)
				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + " to edit provider to " + selProvider + "\n"
				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: " + user + " has updated the url with success\n"
				if printLog == True:
					Parent.Log("INFO:", "[" + ScriptName + "]: "+ user + " has changed the url with success")
				Parent.SendStreamWhisper(user, "/me : [" + ScriptName + "]: Provider changed to " + selProvider +". Viewers can now type !multi in chat to display this link: " + url + " where " + casterName + " is playing " + gameToShow)
			elif entry[0] == "" or entry[0] not in providersRef:
				selProvider = providersLink[int(providersName.index(scriptSettings.multiProvider))]
				SetUrl(selProvider)
				multiMsgToSend = scriptSettings.multiMsg.format(caster = casterName, link = url[:-1], friends = friends[:-1], game = gameToShow)
				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + " to edit provider\n"
				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR: " + user + " failed to update the url. Selected provider in UI remains. (Reason: No provider was given or an invidalid parameter was given by the user)\n"
				if printLog == True:
					Parent.Log("ERROR:", "[" + ScriptName + "]: "+ user + " failed to update the url. Selected provider in UI remains. (Reason: No provider was given or an invalid parameter was give by the user)")
				Parent.SendStreamWhisper(user, "/me : [" + ScriptName + "]: Provider change failed. Enter a valid parameter to change Multi-Stream provider")
	elif not Parent.HasPermission(user, "Moderator", "") and command in setCommands:
		logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + "\n"
		logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR: " + user + " failed to use " + command + ". (Reason: "+ user + " lacks the required permission to use " + command + ")\n"
		if printLog == True:
			Parent.Log("ERROR:", "[" + ScriptName + "]: "+ user + " failed to use " + command + ". (Reason: "+ user + " lacks the required permission to use " + command + ")")
		Parent.SendStreamWhisper(user, "/me : [" + ScriptName + "]: You don't  have permission to use this command")
	
	if command in showCommand and (Parent.HasPermission(user, "Moderator", "") or Parent.HasPermission(user, "Everyone", "")):
		if Parent.IsOnUserCooldown(ScriptName, command, user):
			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + " with the following arguments: "+ str(args) +"\n"
			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR: " + user + " tried to display the link in chat with no success. (Reason: "+ user + " had cooldown on command)\n"
			if printLog == True:
				Parent.Log("ERROR: ", "[" + ScriptName + "]: "+ user + " tried to display the link in chat with no success. (Reason: "+ user +" had cooldown on command)")
			Parent.SendStreamWhisper(user, "/me : [" + ScriptName + "]: @" + user + ", " + command + " is under user cooldown for " + str(Parent.GetUserCooldownDuration(ScriptName, command, user)) + " seconds!")
		elif Parent.IsOnCooldown(ScriptName, command):
			Parent.SendStreamWhisper(user, "/me : [" + ScriptName + "]: @" + user + ", " + command + " is under cooldown for " + str(Parent.GetCooldownDuration(ScriptName, command)) + " seconds!")
			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + " with the following arguments: "+ str(args) +"\n"
			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR: " + user + " tried to display the link in chat with no success. (Reason: command had cooldown)\n"
			if printLog == True:
				Parent.Log("ERROR: ", "[" + ScriptName + "]: "+ user + " tried to display the link in chat with no success. (Reason: command had cooldown)")
		elif not (Parent.IsOnCooldown(ScriptName, command) and Parent.IsOnUserCooldown(ScriptName, command, user)):
			if bool(multiOn):
				Parent.SendStreamMessage(multiMsgToSend)
				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + " to display the Multi-Stream link\n"
				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: " + user + " displayed the Multi-Stream link in chat\n"
				if printLog == True:
					Parent.Log("INFO:", "[" + ScriptName + "]: "+ user + " displayed the Multi-Stream link in chat")
			if not bool(multiOn):
				Parent.SendStreamMessage("/me : " + casterName + " is not Multi-Streaming right now! Try again later...")
				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + " to display the Multi-Stream link\n"
				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR: " + user + " failed to display the Multi-Stream link in chat. (Reason: No Multi-Stream link is created)\n"
				if printLog == True:
					Parent.Log("ERROR:", "[" + ScriptName + "]: " + user + " failed to display the Multi-Stream link in chat. (Reason: No Multi-Stream link is created)")
		if not Parent.HasPermission(user, "Moderator", ""):
			Parent.AddUserCooldown(ScriptName, command, user, coolDown)
		Parent.AddCooldown(ScriptName, command, globalCD)
	return multiMsgToSend

def LogFile():
	global logFileName, logDir, fileSaved, logMessage
	logMessage += "=========\n"
	logMessage += "This is the end of the SettingsLog file\n"
	location = os.path.join(os.getcwd(), logDir)
	try:
		f = open(location + "\\" + logFileName, "w+")
		f.write(logMessage)
		f.close()
		fileSaved = True
		Parent.Log("INFO:", "[" + ScriptName + "]: Log file saved successfully")
	except:
		fileSaved = False
		Parent.Log("ERROR: ", "[" + ScriptName + "]:  Unable to save Log file due to an unexpected error")
	return fileSaved

def SetFriends(names):
	global logMessage, friendsSet, friends
	if names == "":
		logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR: Unable to retrieve friends. (Reason: Friends list is empty)\n"
		if printLog == True:
			Parent.Log("ERROR:", "[" + ScriptName + "]: Unable to retrieve friends. (Reason: Friends list is empty)")
		friendsSet = False
	else:
		friends = ""
		value = names.split(" ")
		for name in value:
			friends += name + "/"
		logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: Friends was set to " + str(friends) + "  \n"
		if printLog == True:
			Parent.Log("INFO:", "[" + ScriptName + "]: Friends was set to: " + str(friends))
		friendsSet = True
	return friendsSet

def SetUrl(selProvider):
	global logMessage, urlSet, url, friends, multiCustom
	casterName = Parent.GetChannelName()
	casterName = Parent.GetChannelName()
	url = "http://" + selProvider + "/" + casterName.lower() + "/" + friends
	urlSet = True
	return urlSet

def SetGame(game):
	global logMessage, gameToShow, gameSet
	casterName = Parent.GetChannelName()
	if game == "auto" or game == "":
		jsonData = json.loads(Parent.GetRequest("https://decapi.me/twitch/game/" + casterName, {}))
		newGame = jsonData["response"]
		gameToShow = newGame
		gameSet = True
	if game != "" and game != "auto":
		newGame = game
		gameToShow = newGame
		gameSet = True
	return gameSet

#---------------------------------------
# SetDefaults Custom User Interface Button
#---------------------------------------
def ReadMeFile():
    location = os.path.join(os.path.dirname(__file__), "MultiStream_ReadMe.txt")
    os.startfile(location)

def ChangesFile():
    location = os.path.join(os.path.dirname(__file__), "MultiStream_Changelog.txt")
    os.startfile(location)

def OpenLogDir():
	location = logDir
	os.startfile(os.path.join(os.getcwd(), location))

def OpenWebSite():
	os.startfile(Website)
