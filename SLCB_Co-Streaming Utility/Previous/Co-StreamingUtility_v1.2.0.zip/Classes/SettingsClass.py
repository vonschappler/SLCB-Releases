import os
import codecs
import json

class Settings(object):
	""" Load in saved settings file if available. Else set default values. """
	def __init__(self, settingsFile=None):
		try:
			with codecs.open(settingsFile, encoding="utf-8-sig", mode="r") as f:
				self.__dict__ = json.load(f, encoding="utf-8")
		except:
			self.multiMsg = "/me {caster} is currently multi-streaming with {friends} at {link} ! Click the link to a multi-view of {game}!"
			self.multiFriends = "caster1"
			self.multiProvider = "MultiTwitch_LIVE ( id = 1 )"
			self.multiCustom = "example.provider"
			self.multiGame = "auto"
			self.setMultiOn = "!setmultion"
			self.setMultiOff = "!setmultioff"
			self.setMultiGame = "!setmultigame"
			self.setMultiProvider = "!setmultisite"
			self.multiDisplay = "!multi"
			self.multiUserCD = 5.0
			self.multiAutoMsg = True
			self.multiAutoCD = 15
			self.printLog = False
			self.autoLog = True

	def Reload(self, jsondata):
		""" Reload settings from AnkhBot user interface by given json data. """
		self.__dict__ = json.loads(jsondata, encoding="utf-8")
		return

	def Save(self, settingsFile):
		""" Save settings contained within to .json and .js settings files. """
		try:
			with codecs.open(settingsFile, encoding="utf-8-sig", mode="w+") as f:
				json.dump(self.__dict__, f, encoding="utf-8", indent=2)
			with codecs.open(settingsFile.replace("json", "js"), encoding="utf-8-sig", mode="w+") as f:
				f.write("var settings = {0};".format(json.dumps(self.__dict__, encoding='utf-8', indent=2)))
		except:
			Parent.Log("ERROR:", "[" + ScriptName + "]: Failed to save settings to file! (Settings)")
		return
