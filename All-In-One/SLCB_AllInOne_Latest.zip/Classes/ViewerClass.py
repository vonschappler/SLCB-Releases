import os
import codecs
import json

class Viewers(object):
	""" Load in saved settings file if available else set default values. """
	def __init__(self, viewerFile=None):
		try:
			with codecs.open(viewerFile, encoding="utf-8-sig", mode="r") as f:
				self.__dict__ = json.load(f, encoding="utf-8")
		except:
			self.viewers = {}

	def Reload(self, jsondata):
		""" Reload settings from AnkhBot user interface by given json data. """
		self.__dict__ = json.loads(jsondata, encoding="utf-8")
		return

	def Save(self, viewerFile):
		""" Save settings contained within to .json and .js settings files. """
		try:
			with codecs.open(viewerFile, encoding="utf-8-sig", mode="w+") as f:
				json.dump(self.__dict__, f, encoding="utf-8", ensure_ascii=False, indent=4, sort_keys=True)
		except:
			Parent.Log("Error: ", ScriptName + ": The viewers file could not be saved! (Viewers)")
		return
