import os
import codecs
import json

class Settings(object):
	""" Load in saved settings file if available. Else set default values. """
	def __init__(self, settingsFile=None):
		try:
			with codecs.open(settingsFile, encoding="utf-8-sig", mode="r") as f:
				self.__dict__ = json.load(f, encoding="utf-8")
		except:
			self.fstVisitPay = 15
			self.fstVisitMsg = "/me [BOT INFO] - {viewer} {caster} welcomes you on your first visit this channel! As a reward for your visit, you got {0} {1}!"
			self.recVisitPay = 50
			self.recVisitMsg = "/me [BOT INFO] - {viewer} {caster} welcomes you on your recurring visit this channel! As a reward for your visit, you got {0} {1}!"
			self.subDoublePay = True
			self.sndCasterMsg = True
			self.casterMsgTxt = "/me [BOT INFO] - {viewer} just joined your stream at {time}!"
			self.setMultiOn = "!setmultion"
			self.setMultiOff = "!setmultioff"
			self.setMultiGame = "!setmultigame"
			self.multiDisplay = "!multi"
			self.multiMsg = "/me [BOT INFO] - {caster} is currently multi-streaming with {friends} at {link} ! Click the link to a multi-view of {game}!"
			self.multiGame = ""
			self.multiUserCD = 5.0
			self.multiAutoMsg = True
			self.multiAutoCD = 10
			self.multiProvider = "multitwitch.live"
			self.payIsLive = True
			self.autoPayOutActives = False
			self.offlinePayment = False
			self.payOutManual = "!pay"
			self.payOutRndManual = "!payrnd"
			self.payActiveAmount = 100
			self.payActiveTimer = 30.0
			self.payActiveMsg = "/me [BOT INFO] - {caster} is giving away {0} {1} to {2} for being active on their chat!"
			self.autoPayActiveRandom = False
			self.payActiveRndValue = 150
			self.payActiveRndTimer = 45.0
			self.payActiveRndMsg = "/me [BOT INFO] - {caster} is randomly giving away {0} {1} to {2} for being active on their chat!"
			self.showViewers = "!viewerlist"
			self.showViewersPerm = "VIP Exclusive"
			self.excViewerLst = "nightbot;moobot;streamelements"
			self.delOneViewer = ""
			self.safeDel = False


	def Reload(self, jsondata):
		""" Reload settings from AnkhBot user interface by given json data. """
		self.__dict__ = json.loads(jsondata, encoding="utf-8")
		return

	def Save(self, settingsFile):
		""" Save settings contained within to .json and .js settings files. """
		try:
			with codecs.open(settingsFile, encoding="utf-8-sig", mode="w+") as f:
				json.dump(self.__dict__, f, encoding="utf-8")
			with codecs.open(settingsFile.replace("json", "js"), encoding="utf-8-sig", mode="w+") as f:
				f.write("var settings = {0};".format(json.dumps(self.__dict__, encoding='utf-8')))
		except:
			Parent.Log("Error:", ScriptName + ": failed to save settings to file! (Settings)")
		return
