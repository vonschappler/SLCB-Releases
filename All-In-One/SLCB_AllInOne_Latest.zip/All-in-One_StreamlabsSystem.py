#---------------------------------------
# Import Libraries
#---------------------------------------
import sys
import os
import codecs
import json
import time
import collections
import random
sys.path.append(os.path.join(os.path.dirname(__file__), "Classes"))
import clr
clr.AddReference("IronPython.SQLite.dll")
clr.AddReference("IronPython.Modules.dll")
from SettingsClass import Settings
from ViewerClass import Viewers

#---------------------------------------
# Script Information
#---------------------------------------
ScriptName = "All-in-One"
Website = "https://rebrand.ly/vonWebsite "
Description = "Common utilities for your stream."
Creator = "von_Schappler"
Version = "1.0.0"

#---------------------------------------
# Variables
#---------------------------------------
global settingsFile
settingsFile = os.path.join(os.path.dirname(__file__), "settings.json")
global viewersFile
viewersFile = os.path.join(os.path.dirname(__file__), "viewers.json")
global scriptSettings
scriptSettings = Settings(settingsFile)
global casterName, remViewer, blockedUsers, streamViewers, revisit, dispName, activeList, url, friends, game, multiMsgToSend
global autoPayOutActives, autoPayActiveRandom, tickCount
isEnabled = True
fstVisitPay = 100
fstVisitMsg = "/me : [BOT INFO] - {viewer}, {caster} welcomes you on your first visit this channel! As a reward for your visit, you got {0} {1}!"
recVisitPay = 250
recVisitMsg = "/me : [BOT INFO] - {viewer}, {caster} welcomes you for revisiting this channel! As a reward for your visit today, you got {0} {1}!"
subDoublePay = True
sndCasterMsg = True
casterMsgTxt = "/me : [BOT INFO] - {viewer} just joined your stream at {time}!"
setMultiOn = "!setmultion"
setmultioff = "!setmultioff"
setMultiGame = "!setmultigame"
multiDisplay = "!multi"
multiMsg = "/me : [BOT INFO] - {caster} is currently multi-streaming with {friends} at {link} ! Click the link to a multi-view of {game}!"
multiGame = ""
multiUserCD = 5.0
multiAutoMsg = True
multiAutoCD = 10
multiProvider = "multitwitch.live"
payIsLive = True
autoPayOutActives = True
offlinePayment = False
payOutManual = "!pay"
payOutRndManual = "!payrnd"
payActiveAmount = 100
payActiveTimer = 30.0
payActiveMsg = "/me : [BOT INFO] - {caster} is giving away {0} {1} to {2} for being active on their chat!"
autoPayActiveRandom = False
payActiveRndValue = 150
payActiveRndTimer = 45.0
payActiveRndMsg = "/me : [BOT INFO] - {caster} is randomly giving away {0} {1} to {2} for being active on their chat!"
showViewers = "!viewers"
showViwersPerm = "VIP Exclusive"
excViewerLst = "nightbot;moobot;streamelements"
delOneViewer = ""
safeDel = False
revisit = False
streamViewers = []
blockedUsers = []
activeList = []
friends = ""
url = ""
multiMsgToSend = ""

tickCount = 0

#---------------------------------------
# Initialize Data on Load
#---------------------------------------
def Init():
	global viewersList, streamViewers, msgCaster, payFstVisit, payRecVisit, curName, url, casterName
	viewersList = Viewers(viewersFile)
	msgCaster = scriptSettings.casterMsgTxt
	payFstVisit = scriptSettings.fstVisitPay
	payRecVisit = scriptSettings.recVisitPay
	msgFstVisit = scriptSettings.fstVisitMsg
	msgRecVisit = scriptSettings.recVisitMsg
	autoPayOutActives = scriptSettings.autoPayOutActives
	autoPayActiveRandom = scriptSettings.autoPayActiveRandom
	curName = Parent.GetCurrencyName()
	viewers = Parent.GetViewerList()
	casterName = Parent.GetChannelName()
	streamViewers = []
	try:
		with codecs.open(os.path.join(os.path.dirname(__file__), "settings.json"), encoding="utf-8-sig", mode="r") as file:
			ReloadSettings(file.read())
	except:
		Parent.Log("Error: ", time.strftime("(%Y/%m/%d - %H:%M:%S) ") + ScriptName + ": Unable to load settings during execution! (Init)")
	for viewer in viewers:
		dispName = Parent.GetDisplayName(viewer)
		try:
			if not viewer in viewersList.viewers:
				viewersList.viewers[viewer] = time.strftime("%Y/%m/%d - %H:%M:%S")
				Parent.Log("Info: ", time.strftime("(%Y/%m/%d - %H:%M:%S) ") + ScriptName + ": " + dispName +" has joined your stream for the first time!")
				if scriptSettings.sndCasterMsg:
					try:
						Parent.SendStreamWhisper(casterName, casterMsgTxt.format(viewer = dispName, time = time.strftime("%H:%M:%S")))
					except:
						Parent.Log("Error: ", time.strftime("(%Y/%m/%d - %H:%M:%S) ") + ScriptName + ": Unable to send whisper to caster! (Init)")
			else:
				Parent.Log("Info: ", time.strftime("(%Y/%m/%d - %H:%M:%S) ") + ScriptName + ": " + dispName +" is revisiting your stream!")
				if scriptSettings.sndCasterMsg:
					try:
						Parent.SendStreamWhisper(casterName, casterMsgTxt.format(viewer = dispName, time = time.strftime("%H:%M:%S")))
					except:
						Parent.Log("Error: ", time.strftime("(%Y/%m/%d - %H:%M:%S) ") + ScriptName + ": Unable to send whisper to caster! (Init)")
		except:
			Parent.Log("Error: ", time.strftime("(%Y/%m/%d - %H:%M:%S) ") + ScriptName + ": Unknown error! (Init)")
	return

#---------------------------
#   [Optional] Reload Settings (Called when a user clicks the Save Settings button in the Chatbot UI)
#---------------------------
def ReloadSettings(jsondata):
	global blockedUsers, scriptSettings, msgCaster, remViewer
	viewersList = Viewers(viewersFile)
	scriptSettings.Reload(jsondata)
	fstVisitPay = scriptSettings.fstVisitPay
	fstVisitMsg = scriptSettings.fstVisitMsg
	recVisitPay = scriptSettings.recVisitPay
	recVisitMsg = scriptSettings.recVisitMsg
	subDoublePay = scriptSettings.subDoublePay
	sndCasterMsg = scriptSettings.sndCasterMsg
	casterMsgTxt = scriptSettings.casterMsgTxt
	setMultiOn = scriptSettings.setMultiOn
	setMultiOff = scriptSettings.setMultiOff
	setMultiGame = scriptSettings.setMultiGame
	multiDisplay = scriptSettings.multiDisplay
	multiMsg = scriptSettings.multiMsg
	multiGame = scriptSettings.multiGame
	multiUserCD = scriptSettings.multiUserCD
	multiAutoMsg = scriptSettings.multiAutoMsg
	multiAutoCD = scriptSettings.multiAutoCD
	multiProvider = scriptSettings.multiProvider
	payIsLive = scriptSettings.payIsLive
	autoPayOutActives = scriptSettings.autoPayOutActives
	offlinePayment = scriptSettings.offlinePayment
	payOutManual = scriptSettings.payOutManual
	payOutRndManual = scriptSettings.payOutRndManual
	payActiveAmount = scriptSettings.payActiveAmount
	payActiveTimer = scriptSettings.payActiveTimer
	payActiveMsg = scriptSettings.payActiveMsg
	autoPayActiveRandom = scriptSettings.autoPayActiveRandom
	payActiveRndValue = scriptSettings.payActiveRndValue
	payActiveRndTimer = scriptSettings.payActiveRndTimer
	payActiveRndMsg = scriptSettings.payActiveRndMsg
	showViewers = scriptSettings.showViewers
	showViewersPerm = scriptSettings.showViewersPerm
	excViewerLst = scriptSettings.excViewerLst
	delOneViewer = scriptSettings.delOneViewer
	safeDel = scriptSettings.safeDel
	msgCaster = scriptSettings.casterMsgTxt
	remViewer = scriptSettings.delOneViewer
	blockedUsers = []
	streamViewers = []
	casterName = Parent.GetChannelName()
	for name in scriptSettings.excViewerLst.replace(" ", "").Split(";"):
		blockedUsers.append(name.lower())
	if not casterName in blockedUsers:
		blockedUsers.append(casterName.lower())
	Parent.Log("Info: ", time.strftime("(%Y/%m/%d - %H:%M:%S) ") + ScriptName + " loaded settings:")
	Parent.Log("Settings: ", "Value to pay to first time visitors: " + str(fstVisitPay))
	Parent.Log("Settings: ", "Message to send to first time visitors: " + str(fstVisitMsg))
	Parent.Log("Settings: ", "Value to pay to recurrent visitors: " + str(recVisitPay))
	Parent.Log("Settings: ", "Message to send to recurrent visitors: " + str(recVisitMsg))
	Parent.Log("Settings: ", "Bonus rewards to subscribers: " + str(subDoublePay))
	Parent.Log("Settings: ", "Send whisper to streamer when a new viewer join: " + str(sndCasterMsg))
	Parent.Log("Settings: ", "Whisper the caster will recieve: " + str(casterMsgTxt))
	Parent.Log("Settings: ", "Command to set link for Multi-Streaming: " + str(setMultiOn))
	Parent.Log("Settings: ", "Command to reset link fro Multi-Streaming: " + str(setMultiOff))
	Parent.Log("Settings: ", "Command to display Multi-Streaming link in chat: " + str(multiDisplay))
	Parent.Log("Settings: ", "Message to sent in chat with Multi-Streaming link: " + str(multiMsg))
	Parent.Log("Settings: ", "Game played during Multi-streaming: " + str(multiGame))
	Parent.Log("Settings: ", "User cooldown between uses of Multi-Streaming display command: " + str(multiUserCD))
	Parent.Log("Settings: ", "Preferred Multi-Streaming provider: " + str(multiProvider))
	Parent.Log("Settings: ", "Allow the script to auto post Multi-Stream link: " + str(multiAutoMsg))
	Parent.Log("Settings: ", "Time between auto Multi-Streaming Messages: " + str(multiAutoCD))
	Parent.Log("Settings: ", "Just AutoPay when live: " + str(payIsLive))
	Parent.Log("Settings: ", "Auto Payout for activity: " + str(autoPayOutActives))
	Parent.Log("Settings: ", "Allow autopay when not streaming: " + str(offlinePayment))
	Parent.Log("Settings: ", "Auto Random Payout: " + str(autoPayActiveRandom))
	Parent.Log("Settings: ", "Payout value: " + str(payActiveAmount))
	Parent.Log("Settings: ", "Payout timer: " + str(payActiveTimer))
	Parent.Log("Settings: ", "Message to send on payout: " + str(payActiveMsg))
	Parent.Log("Settings: ", "Use auto random payout settings: " + str(autoPayActiveRandom))
	Parent.Log("Settings: ", "Maximum random payout value: " + str(payActiveRndValue))
	Parent.Log("Settings: ", "Maximum random payout timer: " + str(payActiveRndTimer))
	Parent.Log("Settings: ", "Message to send on random payout: " + str(payActiveRndMsg))
	Parent.Log("Settings: ", "Command to check stream viewers: " + str(showViewers))
	Parent.Log("Settings: ", "Level permission to check stream viewers: " + str(showViewersPerm))
	if len(blockedUsers) == 0:
		Parent.Log("Settings: ", "No users are blocked for this script execution")
	else:
		Parent.Log("Settings: ", "Blocked Users List")
		for name in blockedUsers:
			Parent.Log("", name)
	Parent.Log("Settings: ","Viewer to be deleted: " + remViewer)
	Parent.Log("Settings: ", "Delete all viewers status: " + str(scriptSettings.safeDel))
	return

#---------------------------------------
#	Script is going to be unloaded
#---------------------------------------
def Unload():
	viewersList.Save(viewersFile)
	return

#---------------------------------------
#	Script is enabled or disabled on UI
#---------------------------------------
def ScriptToggled(state):
	global scriptSettings, isEnabled
	if not state:
		scriptSettings.Save(settingsFile)
		isEnabled = False
	else:
		isEnabled = True
	return

#---------------------------------------
# Execute data and process messages
#---------------------------------------
def Execute(data):
	global scriptSettings, viewer, streamViewers, blockedUsers, showViewers, showViewersPerm, source, multi
	showViewers = scriptSettings.showViewers
	showViewersPerm = scriptSettings.showViewersPerm
	noViewersMsg = "/me : [BOT INFO] - There are no viewers in the list!"
	currentViewers = Parent.GetViewerList()
	activeViewers = Parent.GetActiveUsers()
	activeReward = scriptSettings.payOutManual
	rndActiveRwd = scriptSettings.payOutRndManual
	base = scriptSettings.payActiveAmount
	baseRnd = scriptSettings.payActiveRndValue
	if (data.IsChatMessage() and isEnabled) or (data.IsChatMessage() and not isEnabled):
		if data.IsFromTwitch():
			source = "twitch"
			Multi(source, data.User.lower(), data.GetParam(0), data.Message[len(data.GetParam(0)) + len(" "):])
		if data.IsFromDiscord():
			source = "discord"
			Multi(source, data.User.lower(), data.GetParam(0), data.Message[len(data.GetParam(0)) + len(" "):])
		if Parent.HasPermission(data.User.lower(), "moderator",""):
			if data.IsFromTwitch():
				source = "twitch"
				if data.GetParam(0).lower() == activeReward.lower():
					PayActive(activeViewers, base)
				elif data.GetParam(0).lower() == rndActiveRwd.lower():
					randomViewer = Parent.GetRandomActiveUser()
					if viewer != "":
						PayRandomActive(randomViewer, baseRnd)
			elif data.IsFromDiscord():
				source = "discord"
				if data.GetParam(0).lower() == activeReward.lower():
					if viewer != "":
						PayActive(activeViewers, base)
				elif data.GetParam(0).lower() == rndActiveRwd.lower():
					randomViewer = Parent.GetRandomActiveUser()
					if viewer != "":
						PayRandomActive(randomViewer, baseRnd)
		if Parent.HasPermission(data.User.lower(), showViewersPerm, "") or Parent.HasPermission(data.User.lower(), "VIP Exclusive", ""):
			if data.IsFromTwitch():
				if data.GetParam(0).lower() == showViewers.lower():
					if len(currentViewers) == 0:
						Parent.SendStreamWhisper(data.User, noViewersMsg)
					else:
						Parent.SendStreamWhisper(data.User, "/me : [BOT INFO] - " + time.strftime("(%Y/%m/%d - %H:%M:%S) ") + "Those are your {0} current viewers for this stream session: ".format(len(currentViewers)))
						message = "/me : "
						for name in currentViewers:
							message += name + ", "
						Parent.SendStreamWhisper(data.User, message[:-2])
			elif data.IsFromDiscord():
				if data.GetParam(0).lower() == showViewers.lower():
					if len(currentViewers) == 0:
						Parent.SendDiscordDM(data.User, noViewersMsg)
					else:
						Parent.SendDiscordDM(data.User, "/me : [BOT INFO] - " + time.strftime("(%Y/%m/%d - %H:%M:%S) ") + "Those are your {0} current viewers for this stream session: ".format(len(currentViewers)))
						message = "/me : "
						for name in currentViewers:
							message += name + ", "
						Parent.SendDiscordDM(data.User, message[:-2])
	if isEnabled and data.IsChatMessage():
		if not (data.User in viewersList.viewers) and not (data.User.lower() in blockedUsers):
			SendFstMsgWelcome(data.User)
		else:
			SendRecMsgWelcome(data.User)
	return

def GetKeyByIndex(dictionary, index):

	return

#---------------------------------------
# Tick
#---------------------------------------
def Tick():
	global tickCount


	autoPayOutActives = scriptSettings.autoPayOutActives
	autoPayActiveRandom = scriptSettings.autoPayActiveRandom
	payIsLive = scriptSettings.payIsLive
	offlinePayment = scriptSettings.offlinePayment
	base = scriptSettings.payActiveAmount
	baseRnd = scriptSettings.payActiveRndValue
	multiAutoCD = scriptSettings.multiAutoCD
	multiAutoMsg = scriptSettings.multiAutoMsg

	if isEnabled or isEnabled:
		viewers = Parent.GetViewerList()
		for viewer in viewers:
			if viewer != "":
				try:
					if not viewer in viewersList.viewers and not viewer.lower() in blockedUsers:
						SendFstMsgWelcome(viewer)
					else:
						SendRecMsgWelcome(viewer)
				except:
					Parent.Log("Error:", time.strftime("(%Y/%m/%d - %H:%M:%S) ") + ScriptName + ": Unknown error! (Tick)")

	if payIsLive and Parent.IsLive():
		if tickCount == 0:
			Parent.AddCooldown(ScriptName, "liveAutoPay", cd)
			tickCount = 1
		elif tickCount > 0:
			if autoPayOutActives and not Parent.IsOnCooldown(ScriptName,"liveAutoPay"):
				if autoPayActiveRandom:
					cd = random.randint(1, scriptSettings.payActiveRndTimer) * 60
					viewer = Parent.GetRandomActiveUser()
					if viewer != "":
						PayRandomActive(viewer, baseRnd)
					Parent.AddCooldown(ScriptName, "liveAutoPay", cd)
					cd = 0
				elif autoPayOutActives:
					cd = scriptSettings.payActiveTimer * 60
					viewer = Parent.GetActiveUsers()
					if viewer != "":
						PayActive(viewer, base)
					Parent.AddCooldown(ScriptName, "liveAutoPay", cd)
					cd = 0
	if not payIsLive and offlinePayment:
		if tickCount == 0:
			Parent.AddCooldown(ScriptName, "liveAutoPay", cd)
			tickCount = 1
			if autoPayOutActives and not Parent.IsOnCooldown(ScriptName,"liveAutoPay"):
				if autoPayActiveRandom:
					cd = random.randint(1, scriptSettings.payActiveRndTimer) * 60
					viewer = Parent.GetRandomActiveUser()
					PayRandomActive(viewer, baseRnd / 2)
					Parent.AddCooldown(ScriptName, "liveAutoPay", cd)
					cd = 0
				elif autoPayOutActives:
					cd = scriptSettings.payActiveTimer * 60
					viewer = Parent.GetActiveUsers()
					PayActive(viewer, base / 2)
					Parent.AddCooldown(ScriptName, "liveAutoPay", cd)
					cd = 0

	if multiAutoMsg and not Parent.IsOnCooldown(ScriptName, "autoMulti") and multiMsgToSend != "" and friends != "":
		cd = scriptSettings.multiAutoCD * 60
		Parent.SendStreamMessage(multiMsgToSend)
		Parent.AddCooldown(ScriptName, "autoMulti", cd)
	return

#---------------------------------------
# Functions
#---------------------------------------
def SendFstMsgWelcome(viewer):
	value = scriptSettings.fstVisitPay
	msg = scriptSettings.fstVisitMsg
	casterMsg = scriptSettings.sndCasterMsg
	casterTxt = scriptSettings.casterMsgTxt
	try:
		dispName = Parent.GetDisplayName(viewer)
		Parent.Log("Info: ", time.strftime("(%Y/%m/%d - %H:%M:%S) ") + ScriptName + ": " + viewer +" has joined your stream for the first time!")
		viewersList.viewers[viewer] = time.strftime("%Y/%m/%d - %H:%M:%S")
		Parent.AddPoints(viewer, value)
		Parent.SendStreamWhisper(viewer, msg.format(value, curName, caster = casterName, viewer = dispName))
		streamViewers.append(viewer)
		if casterMsg:
			try:
				Parent.SendStreamWhisper(casterName, casterTxt.format(viewer = viewer, time = time.strftime("%H:%M:%S")))
			except:
				Parent.Log("Error: ", time.strftime("(%Y/%m/%d - %H:%M:%S) ") + ScriptName + ": Unable to send whisper to caster! (SendFstMsgWelcome)")
	except:
		Parent.Log("Error: ", time.strftime("(%Y/%m/%d - %H:%M:%S) ") + ScriptName + ": Unable to send whisper to "+ viewer + "! (SendFstMsgWelcome)")
	return

def SendRecMsgWelcome(viewer):
	value = scriptSettings.recVisitPay
	msg = scriptSettings.recVisitMsg
	casterMsg = scriptSettings.sndCasterMsg
	casterTxt = scriptSettings.casterMsgTxt
	if viewer != "":
		try:
			if not revisit and viewer not in streamViewers and viewer.lower() not in blockedUsers:
				try:
					dispName = Parent.GetDisplayName(viewer)
					if Parent.HasPermission(viewer, "VIP+", "") and scriptSettings.subDoublePay:
						value *= 2
					Parent.Log("Info: ", time.strftime("(%Y/%m/%d - %H:%M:%S) ") + ScriptName + ": " + dispName +" is revisiting your stream!")
					Parent.AddPoints(viewer, value)
					Parent.SendStreamWhisper(viewer, msg.format(value, curName, caster = casterName, viewer = dispName))
					if casterMsg:
						try:
							Parent.SendStreamWhisper(caster, casterTxt.format(viewer = dispName, time = time.strftime("%H:%M:%S")))
						except:
							Parent.Log("Error: ", time.strftime("(%Y/%m/%d - %H:%M:%S) ") + ScriptName + ": Unable to send whisper to caster! (SendRecMsgWelcome)")
				except:
					Parent.Log("Error: ", time.strftime("(%Y/%m/%d - %H:%M:%S) ") + ScriptName + ": Unable to send whisper to "+ dispName + "! (SendRecMsgWelcome)")
			streamViewers.append(viewer)
		except:
			Parent.Log("Error:", time.strftime("(%Y/%m/%d - %H:%M:%S) ") + ScriptName + ": Unknown error! (SendRecMsgWelcome)")
	return

def PayActive(viewers, baseValue):
	vAmount = baseValue
	sAmount = vAmount * 2
	activeList = viewers
	blockList = blockedUsers
	vDict = {}
	vPay = ""
	sDict = {}
	sPay = ""
	msgNoAll = "/me : [BOT INFO] - No viewers, subscribers or VIPs are eligible for this channel activity rewards!"
	msgNoViewers = "/me : [BOT INFO] - No viewers are eligible for this channel activity rewards!"
	msgNoSubs = "/me : [BOT INFO] - No subscribers or VIPs are eligible for this channel activity rewards!"
	toBeContinued = " (and the reward list continues...)"
	activeList = [name for name in activeList if name.lower() not in blockList]
	if bool(activeList):
		for name in activeList:
			if Parent.HasPermission(name, "Vip+",""):
				sDict[name] = sAmount
				sPay += name + ", "
			else:
				vDict[name] = vAmount
				vPay += name + ", "
		else:
			Parent.AddPointsAll(vDict)
			Parent.AddPointsAll(sDict)
		msgOnChat = scriptSettings.payActiveMsg.format(str(vAmount), curName, vPay, caster = casterName)
		if len(msgOnChat) > (490 - len(toBeContinued)):
			msgOnChat = msgOnChat[:-len(toBeContinued)] + toBeContinued
		if not vPay == "":
			Parent.SendStreamMessage(msgOnChat)
		else:
			Parent.SendStreamMessage(msgNoViewers)
		msgOnChat = scriptSettings.payActiveMsg.format(str(sAmount), curName, sPay, caster = casterName) + " - subscribers and vip bonus!"
		if len(msgOnChat) > (490 - len(toBeContinued)):
			msgOnChat = msgOnChat[:-len(toBeContinued)] + toBeContinued
		if not sPay == "":
			Parent.SendStreamMessage(msgOnChat)
		else:
			Parent.SendStreamMessage(msgNoSubs)
	else:
		Parent.SendStreamMessage(msgNoAll)

	vPay = ""
	vDict = {}
	sPay = ""
	sDict = {}
	activeList = []
	return

def PayRandomActive(viewer, baseValue):
	vAmount = random.randint(0, baseValue + 1)
	sAmount =  vAmount * 2
	viewerToPay = viewer
	blockList = blockedUsers
	msgNoPay = "/me : [BOT INFO] - Nobody is eligible for this random channel activity rewards!"
	if (viewerToPay.lower() in blockList):
		Parent.SendStreamMessage(msgNoPay)
	else:
		if Parent.HasPermission(viewerToPay, "Vip+",""):
				Parent.AddPoints(viewerToPay, sAmount)
				msgOnChat = scriptSettings.payActiveRndMsg.format(str(sAmount), curName, viewer, caster = casterName)  + " - subscribers and vip bonus!"
				Parent.SendStreamMessage(msgOnChat)
		else:
			Parent.AddPoints(viewerToPay, vAmount)
			msgOnChat = scriptSettings.payActiveRndMsg.format(str(vAmount), curName, viewer, caster = casterName)
			Parent.SendStreamMessage(msgOnChat)
	viewer = ""
	amount = 0
	return

def Multi(source, user, message, args):
	global selProvider, cooldown, command, caster, url, friends, game, multiMsgToSend
	selProvider = scriptSettings.multiProvider
	coolDown = scriptSettings.multiUserCD * 60
	command = message
	setCommands = [scriptSettings.setMultiOn, scriptSettings.setMultiOff, scriptSettings.setMultiGame]
	showCommand = [scriptSettings.multiDisplay]
	caster = Parent.GetChannelName().lower()
	toSend = scriptSettings.multiMsg
	source = source
	game = scriptSettings.multiGame

	if Parent.HasPermission(user, "Moderator", "") and command in setCommands:
		if bool(command == setCommands[0]) and not bool(args):
			friends = ""
			url = "http://" + selProvider + "/" + casterName + "/"
			multiMsgToSend = ""
#			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + " with the following arguments: "+ str(args) +"\n"
#			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR: " + user + " tried to create a URL multi-stream message with no success. (Reason: Missing arguments)\n"
#			if printLog == True:
#				Parent.Log("ERROR: ", "[" + ScriptName + "]: "+ user + " tried to create a URL multi-stream message with no success. (Reason: Missing arguments)")
			Parent.SendStreamWhisper(user, "/me : [" + ScriptName + "]: Fail to create multi-stream link. You missed the required info for creating the multi-stream link.")
		if bool(command == setCommands[1]):
			friends = ""
			url = "http://" + selProvider + "/" + casterName + "/"
			multiMsgToSend = ""
#			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + " with the following arguments: "+ str(args) +"\n"
#			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: " + user + " disabled the multi-stream link with success.\n"
#			if printLog == True:
#				Parent.Log("SETTINGS: ", "[" + ScriptName + "]: "+ user + " disabled the multi-stream link with success.")
			Parent.SendStreamWhisper(user, "/me : [" + ScriptName + "]: Multi-stream is disabled. All friends erased...")
		if bool(command == setCommands[2]) and bool(args):
			if args == "auto":
				jsonData = json.loads(Parent.GetRequest("https://decapi.me/twitch/game/" + casterName,{}))
				newGame = jsonData["response"]
				gameToShow = newGame
				gameSet = True
			else:
				newGame = args
				gameToShow = newGame
				gameSet = True
			multiMsgToSend = scriptSettings.multiMsg.format(caster = casterName, link = url, friends = friends[:-1], game = gameToShow)
#			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + " with the following arguments: "+ str(args) +"\n"
#			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: "+ user + " has changed the game to: " + gameToShow + "\n"
#			if printLog == True:
#				Parent.Log("SETTINGS: ", "[" + ScriptName + "]: "+ user + " has changed the game name to " + gameToShow + ".")
			Parent.SendStreamWhisper(user, "/me : [" + ScriptName + "]: Game was updated. Viewers can now type !multi in chat to display this link: " + url + " where you are playing " + gameToShow + "." )
		if bool(command == setCommands[2]) and not bool(args):
#			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + " with the following arguments: "+ str(args) +"\n"
#			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR: " + user + " tried to change the game, with no success. (Reason: Missing arguments)\n"
#			if printLog == True:
#				Parent.Log("ERROR: ", "[" + ScriptName + "]: "+ user + " tried to change the game with no success. (Reason: Missing arguments)")
			Parent.SendStreamWhisper(user, "/me : [" + ScriptName + "]: Fail to change the game, you need to enter the game name after the command.")
		if bool(command == setCommands[0]) and bool(args):
			friends = ""
			url = ""
			if gameSet == True:
				gameToShow = newGame
			else:
				if not bool(game):
					jsonData = json.loads(Parent.GetRequest("https://decapi.me/twitch/game/" + casterName,{}))
					game = jsonData["response"]
					gameToShow = game
					gameSet = False
				else:
					game = scriptSettings.multiGame
					gameToShow = game
					gameSet = False
			url = "http://" + selProvider + "/" + casterName + "/"
			args = args.split(" ")
			for name in args:
				friends += name + "/"
		 	url += friends
			multiMsgToSend = scriptSettings.multiMsg.format(caster = casterName, link = url, friends = friends[:-1], game = gameToShow)
#			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + " with the following arguments: "+ str(args) +"\n"
#			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: " + user + " changed friends " + casterName + " is playing with to: " + str(friends) + "\n"
#			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: " + user + " has changed the URL to: " + str(url) + "\n"
#			Parent.Log("", str(printLog))
#			if printLog == True:
#				Parent.Log("INFO: ", "[" + ScriptName + "]: "+ user + " changed friends " + casterName + " is playing with to: " + str(friends) + ". By doing it, the old multi-strem link was changed to a new one (" + url + ")")
			Parent.SendStreamWhisper(user, "/me : [" + ScriptName + "]: Multi-stream link is set correctly. Viewers can now type !multi in chat to display this link: " + url + " where you are playing " + gameToShow + ".")
	if not Parent.HasPermission(user, "Moderator", "") and command in setCommands:
#		logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + " with the following arguments: "+ str(args) +"\n"
#		logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR: " + user + " tried to create a URL multi-stream message with no success. (Reason: Missing permisions)\n"
#		Parent.Log("ERROR: ", "[" + ScriptName + "]: "+ user + " tried to create a URL multi-stream message with no success. (Reason: Missing permisions)")
		Parent.SendStreamWhisper(user, "/me : [" + ScriptName + "]: You don't have the permission to do this!")
	if Parent.HasPermission(user, "Everyone", "") and command in showCommand:
		if Parent.IsOnUserCooldown(ScriptName, command, user):
#			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + " with the following arguments: "+ str(args) +"\n"
#			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR: " + user + " tried to display the link in chat with no success. (Reason: "+ user + " had colldown on command).\n"
#			if printLog == True:
#				Parent.Log("ERROR: ", "[" + ScriptName + "]: "+ user + " tried to display the link in chat with no success. (Reason: "+ user +" had cooldown on command)")
			Parent.SendStreamWhisper(user, "/me : [" + ScriptName + "]: " + user + ", " + command + " is under user cooldown for " + str(Parent.GetUserCooldownDuration(ScriptName, command, user)) + " seconds!")
		if not Parent.IsOnUserCooldown(ScriptName, command, user):
			if bool(friends):
				multiMsgToSend = scriptSettings.multiMsg.format(caster = casterName, link = url, friends = friends[:-1], game = gameToShow)
#				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + " with the following arguments: "+ str(args) +"\n"
#				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: " + user + " displayed the link in chat.\n"
#				if printLog == True:
#					Parent.Log("INFO:", "[" + ScriptName + "]: "+ user + " displayed the link in chat")
				Parent.SendStreamMessage(multiMsgToSend)
			if not bool(friends):
				multiMsgToSend = url
#				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + " with the following arguments: "+ str(args) +"\n"
#				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR: " + user + " tried to display the link in chat with no success. (Reason: No URL was set).\n"
#				if printLog == True:
#					Parent.Log("ERROR:", "[" + ScriptName + "]: "+ user + "tried to display the link in chat with no success. (Reason: No URL was set)")
				Parent.SendStreamMessage("/me : " + casterName + " is not multi-streaming right now! Try again later...")
			if not Parent.HasPermission(user, "moderator", ""):
				Parent.AddUserCooldown(ScriptName, command, user, coolDown)
	return multiMsgToSend

#---------------------------------------
# SetDefaults Custom User Interface Button
#---------------------------------------
def DelAllViewers():
	global confirmation, safeDel
	confirmation = scriptSettings.safeDel
	if confirmation:
		viewersList.viewers = {}
		Parent.Log("Info: ", time.strftime("(%Y/%m/%d - %H:%M:%S) ") + ScriptName + ": All viewers removed from your viewers file!")
		confirmation = ""
	else:
		Parent.Log("Error: ", time.strftime("(%Y/%m/%d - %H:%M:%S) ") + ScriptName + ": Unable to reset your viewers file. Read the documentation for details. (DellAllViewerts)")
	return

def LogViewers():
	global viewersList
	if len(viewersList.viewers) == 0:
		Parent.Log("Info: ", time.strftime("(%Y/%m/%d - %H:%M:%S) ") + ScriptName + ": Your viewer list is empty!")
	else:
		Parent.Log("Info:", "Viewers file log:")
		Parent.Log("Format:", "viwerName (YYYY/MM/DD - HH:MM:SS)")
		ordered = collections.OrderedDict(sorted(viewersList.viewers.items()))
		for viewer, t in ordered.iteritems():
			Parent.Log("", viewer + " (" + t + ")")
	return

def DelSelViewer():
	global remViewer, delOneViewer
	remViewer = scriptSettings.delOneViewer
	if remViewer.replace(" ","") != "":
		Parent.Log("Info: ", time.strftime("(%Y/%m/%d - %H:%M:%S) ") + ScriptName + ": Deleting " + remViewer + " from your viewers file...")
		if remViewer in viewersList.viewers:
			del viewersList.viewers[remViewer]
			Parent.Log("Info: ", time.strftime("(%Y/%m/%d - %H:%M:%S) ") + ScriptName + ": Viewer {0} was removed from your viewer file!".format(remViewer))
			delOneViewer = ""
			remViewer = ""
		else:
			Parent.Log("Error: ", time.strftime("(%Y/%m/%d - %H:%M:%S) ") + ScriptName + ": Your viewer file does not have a viewer called {0}!".format(remViewer) + " (DelSelViewer)")
	else:
		Parent.Log("Error: ", time.strftime("(%Y/%m/%d - %H:%M:%S) ") + ": Unable to get a viewer name! Read the documentation for details. (DelSelViewer)")
	return

def ReadMeFile():
    location = os.path.join(os.path.dirname(__file__), "AllInOne_ReadMe.txt")
    os.startfile(location)

def ChangesFile():
    location = os.path.join(os.path.dirname(__file__), "AllInOne_Changelog.txt")
    os.startfile(location)

def OpenWebSite():
	os.startfile(Website)
