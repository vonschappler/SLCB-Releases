#---------------------------------------
# Import Libraries
#---------------------------------------
import sys
import os
import codecs
import json
import collections
import ctypes
import time
from shutil import copy
sys.path.append(os.path.join(os.path.dirname(__file__), "Classes"))
import clr
clr.AddReference("IronPython.SQLite.dll")
clr.AddReference("IronPython.Modules.dll")
from CasterClass import Casters
from SettingsClass import Settings
import re

#---------------------------------------
# Script Information
#---------------------------------------
ScriptName = "Custom ShoutOut Text Version"
Website = "https://rebrand.ly/vonWebsite"
Description = "Shout out pre-defined casters with custom messages."
Creator = "von_Schappler"
Version = "1.0.0:tv"

#---------------------------------------
# Variables
#---------------------------------------
global castersTwHandle, castersChatMsg, castersAllow, castersShout
global castersFile, settingsFile, scriptSettings, logDir, fileSaved, isEnabled
global logFileName, logMessage, autoLog, printLog, cmdList
global shoutRaiderMessage, minRaidersToShout, addRaidersToCaster, casterShout
settingsFile = os.path.join(os.path.dirname(__file__), "settings.json")
castersFile = os.path.join(os.path.dirname(__file__), "casters.json")
castersBackup = os.path.join(os.path.dirname(__file__), "casters.json.bk")
logDir = os.path.join(os.path.dirname(__file__), "Log")
scriptSettings = Settings(settingsFile)
castersList = Casters(castersFile)
isEnabled = True
autoShoutOut = True
shoutOutOnJoin = False
autoShoutRaiders = False
shoutRaiderMessage = "Hey, peeps! We just got raided by {raider} with other {count} viewers! Visit {url} and follow this person, so you can watch gameplays of {game}!"
minRaidersToShout = 1
addRaidersToCaster = True
manualShoutCommand = "!caster"
shoutPerms = "Moderator"
defaultShoutOutMsg = "If you don't know {caster} yet, please drop them a follow at their channel at {url} so you can watch cool gameplays of {game}!"
globalCoolDown = 5
addCasterCmd = "!addcaster"
edtCasterCmd = "!setcaster"
delCasterCmd = "!delcaster"
chkCasterCmd = "!chkcaster"
delAllCasters = False
createBackup = True
printLog = False
autoLog = True
fileSaved = False
logFileName = "CustomShoutOutLog_"
castersTwHandle = []
castersChatMsg = []
castersAllow = []
castersShout = []
cmdList = [manualShoutCommand, addCasterCmd, edtCasterCmd, delCasterCmd, chkCasterCmd]

#---------------------------------------
# Initialize Data on Load
#---------------------------------------
def Init():
    if not os.path.exists(logDir):
        os.makedirs(logDir)
    try:
        with codecs.open(settingsFile, encoding="utf-8-sig", mode="r") as f:
            ReloadSettings(f.read())
    except:
        Parent.Log("ERROR:", "[" + ScriptName + "]:  Unable to load settings during execution! (Init)")
    for item in castersList.casters:
        castersTwHandle.append(item['twHandle'].lower())
        castersChatMsg.append(item['chatMsg'])
        castersAllow.append(item['allow'])
    return

#---------------------------
#   [Optional] Reload Settings (Called when a user clicks the Save Settings button in the Chatbot UI)
#---------------------------
def ReloadSettings(jsondata):
    global logFileName, printLog, logMessage, cmdList, shoutRaiderMessage, minRaidersToShout, addRaidersToCaster
    global autoShoutOut, shoutOutOnJoin, autoShoutRaiders, manualShoutCommand, shoutPerms, defaultShoutOutMsg, globalCoolDown
    global addCasterCmd, edtCasterCmd, delCasterCmd, chkCasterCmd, delAllCasters, createBackup, printLog, autoLog
    scriptSettings.Reload(jsondata)
    autoShoutOut = scriptSettings.autoShoutOut
    shoutOutOnJoin = scriptSettings.shoutOutOnJoin
    autoShoutRaiders = scriptSettings.autoShoutRaiders
    shoutRaiderMessage = scriptSettings.shoutRaiderMessage
    minRaidersToShout = scriptSettings.minRaidersToShout
    addRaidersToCaster = scriptSettings.addRaidersToCaster
    manualShoutCommand = scriptSettings.manualShoutCommand
    shoutPerms = scriptSettings.shoutPerms
    defaultShoutOutMsg = scriptSettings.defaultShoutOutMsg
    globalCoolDown = scriptSettings.globalCoolDown
    addCasterCmd = scriptSettings.addCasterCmd
    edtCasterCmd = scriptSettings.edtCasterCmd
    delCasterCmd = scriptSettings.delCasterCmd
    chkCasterCmd = scriptSettings.chkCasterCmd
    delAllCasters = scriptSettings.delAllCasters
    createBackup = scriptSettings.createBackup
    printLog = scriptSettings.printLog
    autoLog = scriptSettings.autoLog
    cmdList = [scriptSettings.manualShoutCommand, scriptSettings.addCasterCmd, scriptSettings.edtCasterCmd, scriptSettings.delCasterCmd, scriptSettings.chkCasterCmd]
    logFileName += time.strftime("%Y%m%d_%H%M%S") + ".log"
    logMessage = time.strftime("[%Y/%m/%d@%H:%M:%S]") + " This is the begin of the Log data for " + ScriptName + ":\n"
    logMessage += "=========\n"
    logMessage += "Last saved settings:\n"
    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Auto-ShoutOut saved casters? " + str(autoShoutOut) + "\n"
    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Auto-ShoutOut when caster joins channel? " + str(shoutOutOnJoin) + "\n"
    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Auto-ShoutOut raiders? " + str(autoShoutRaiders) + "\n"
    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Message used when Auto-ShoutOut raiders: " + str(shoutRaiderMessage) + "\n"
    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Minimum raiders required to Auto-ShoutOut raiders: " + str(minRaidersToShout) + "\n"
    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Save raider to casters file? " + str(addRaidersToCaster) + "\n"
    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Command for manual ShoutOut: " + str(manualShoutCommand) + "\n"
    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Permission to use the command: " + str(shoutPerms) + "\n"
    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Default message for ShoutOuts: " + str(defaultShoutOutMsg) + "\n"
    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Global cooldown (in secdonds): " + str(globalCoolDown) + "\n"
    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Command to add a new caster to Auto-ShoutOut: " + str(addCasterCmd) + "\n"
    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Command to edit information from a caster to Auto-ShoutOut: " + str(edtCasterCmd) + "\n"
    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Command to delete a caster from Auto-ShoutOut: " + str(delCasterCmd) + "\n"
    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Command to check a caster saved information: " + str(chkCasterCmd) + "\n"
    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Delete all casters? " + str(delAllCasters) + "\n"
    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Create backup before delete casters file? " + str(createBackup) + "\n"
    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Display Script log in the ChatBot?: " + str(printLog) + "\n"
    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: AutoSave ScriptLog file? " + str(autoLog) + "\n"
    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: Initial data loaded from castersFile:\n"
    for item in castersList.casters:
        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "CASTER: " + item["twHandle"] + " will be called in chat with the message: \"" + item["chatMsg"] + "\" - allowed status: " + str(item['allow']) + "\n"
    logMessage += "=========\n"
    if printLog == True:
        Parent.Log("INFO:", time.strftime("(%Y/%m/%d - %H:%M:%S) ") + ScriptName + " last saved settings:")
        Parent.Log("SETTINGS:", "[" + ScriptName + "]: Auto ShoutOut saved casters? " + str(autoShoutOut))
        Parent.Log("SETTINGS:", "[" + ScriptName + "]: ShoutOut when caster joins channel? " + str(shoutOutOnJoin))
        Parent.Log("SETTINGS:", "[" + ScriptName + "]: Auto ShoutOut raiders? " + str(autoShoutRaiders))
        Parent.Log("SETTINGS:", "[" + ScriptName + "]: Message used when Auto-ShoutOut raiders: " + str(shoutRaiderMessage))
        Parent.Log("SETTINGS:", "[" + ScriptName + "]: Minimum raiders required to Auto-ShoutOut raiders: " + str(minRaidersToShout))
        Parent.Log("SETTINGS:", "[" + ScriptName + "]: Save raider to casters file? " + str(addRaidersToCaster))
        Parent.Log("SETTINGS:", "[" + ScriptName + "]: Command for manual ShoutOut: " + str(manualShoutCommand))
        Parent.Log("SETTINGS:", "[" + ScriptName + "]: Permission to use the command: " + str(shoutPerms))
        Parent.Log("SETTINGS:", "[" + ScriptName + "]: Default message for ShoutOuts: " + str(defaultShoutOutMsg))
        Parent.Log("SETTINGS:", "[" + ScriptName + "]: Global cooldown (in secdonds): " + str(globalCoolDown))
        Parent.Log("SETTINGS:", "[" + ScriptName + "]: Command to add a new caster to Auto-ShoutOut: " + str(addCasterCmd))
        Parent.Log("SETTINGS:", "[" + ScriptName + "]: Command to edit information from a caster to Auto-ShoutOut: " + str(edtCasterCmd))
        Parent.Log("SETTINGS:", "[" + ScriptName + "]: Command to delete a caster from Auto-ShoutOut: " + str(delCasterCmd))
        Parent.Log("SETTINGS:", "[" + ScriptName + "]: Command to check a caster saved information: " + str(chkCasterCmd))
        Parent.Log("SETTINGS:", "[" + ScriptName + "]: Delete all casters? " + str(delAllCasters))
        Parent.Log("SETTINGS:", "[" + ScriptName + "]: Create backup before delete casters file? " + str(createBackup))
        Parent.Log("SETTINGS:", "[" + ScriptName + "]: Display Script log in the ChatBot?: " + str(printLog))
        Parent.Log("SETTINGS:", "[" + ScriptName + "]: AutoSave ScriptLog file? " + str(autoLog))
        Parent.Log("INFO:", "[" + ScriptName +"]: Initial data loaded from castersFile:")
        for item in castersList.casters:
            Parent.Log("CASTER: ", item["twHandle"] + " will be called in chat with the message: \"" + item["chatMsg"] + "\" - allowed status: " + str(item['allow']))
    return

#---------------------------------------
#	Script is going to be unloaded
#---------------------------------------
def Unload():
    if not fileSaved and autoLog:
        LogFile()
	return

#---------------------------------------
#	Script is enabled or disabled on UI
#---------------------------------------
def ScriptToggled(state):
    if not state:
        scriptSettings.Save(settingsFile)
        isEnabled = False
    else:
        isEnabled = True
	return isEnabled

#---------------------------------------
# Execute data and process messages
#---------------------------------------
def Execute(data):
    global castersShout, casterShout, wasRaided
    if data.IsChatMessage() and (isEnabled or (isEnabled and Parent.IsLive())):
        user = data.User
        cmd = data.GetParam(0).lower()
        if cmd in cmdList and cmd == cmdList[0]:
            Shout("twitch", user.lower(), cmd, data.Message)
        if cmd in cmdList and cmd == cmdList[1]:
            Add("twitch", user.lower(), cmd, data.Message)
        if cmd in cmdList and cmd == cmdList[2]:
            Edit("twitch", user.lower(), cmd, data.Message)
        if cmd in cmdList and cmd == cmdList[3]:
            Delete("twitch", user.lower(), cmd, data.Message)
        if cmd in cmdList and cmd == cmdList[4]:
            Check("twitch", user.lower(), cmd, data.Message)
        if user.lower() not in castersShout and user.lower() in castersTwHandle and not shoutOutOnJoin:
            casterToSo = user.lower()
            ShoutCaster(casterToSo)
            if casterShout == True:
                castersShout.append(casterToSo)
    if (data.IsRawData() and data.IsFromTwitch()) and (isEnabled or (isEnabled and Parent.IsLive())):
        rawData = data.RawData
        CheckRaid(rawData)
        if wasRaided == True and autoShoutRaiders:
            ShoutRaider(raiderName)
            if addRaidersToCaster:
                if raiderName not in castersList:
                    AddRaider()
                elif raiderName in castersList:
                    UpdateRaider()
    return

#---------------------------------------
# Tick
#---------------------------------------
def Tick():
    global castersShout, casterShout
    if (isEnabled) or (isEnabled and Parent.IsLive()):
        viewers = Parent.GetViewerList()
        for viewer in viewers:
            if viewer.lower() not in castersShout and viewer.lower() in castersTwHandle and shoutOutOnJoin:
                casterToSo = viewer.lower()
                ShoutCaster(casterToSo)
                if casterShout == True:
                    castersShout.append(casterToSo)
    return


#---------------------------------------
# Functions
#---------------------------------------
def Shout(source, user, cmd, message):
    global logMessage, printLog
    entry = []
    for word in message.Split(" "):
        entry.append(word.lower())
    params = len(entry) - 1
    if (Parent.HasPermission(user, "Moderator", "") or Parent.HasPermission(user, "VIP Exclusive", "")) and params == 1:
        casterToSo = Parent.GetDisplayName(RemovePound(entry[1]))
        if casterToSo.lower() in castersTwHandle:
            pos = castersTwHandle.index(casterToSo.lower())
            if castersAllow[pos] == True:
                if not Parent.IsOnCooldown(ScriptName, "shout"):
                    url = "http://twitch.tv/" + casterToSo
                    jsonData = json.loads(Parent.GetRequest("https://decapi.me/twitch/game/" + casterToSo, {}))
                    game = jsonData["response"]
                    if bool(castersChatMsg[pos] != "Default"):
                        msgToSend = "/me " + castersChatMsg[pos].format(caster = casterToSo, url = url, game = game)
                    else:
                        msgToSend = "/me " + defaultShoutOutMsg.format(caster = casterToSo, url = url, game = game)
                    Parent.SendStreamMessage(msgToSend)
                    Parent.AddCooldown(ScriptName, "shout", globalCoolDown)
                    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " to ShoutOut " + casterToSo + "\n"
                    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO:" + casterToSo + " was called by the bot sucessfully\n"
                    if printLog:
                        Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " to ShoutOut " + casterToSo)
                        Parent.Log("INFO:", "[" + ScriptName + "]: " + casterToSo + " was called by the bot sucessfully")
                elif Parent.IsOnCooldown(ScriptName, "shout"):
                    msgToSend = "/me [" + ScriptName + "]: @" + user +" , you were unable to shout " + casterToSo + ", because " + entry[0] + " is on cooldown."
                    Parent.SendStreamMessage(msgToSend)
                    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " to ShoutOut " + casterToSo + "\n"
                    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR:" + casterToSo + " was not called by the bot. (Reason: Command was in global cooldown)\n"
                    if printLog:
                        Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " to ShoutOut " + casterToSo)
                        Parent.Log("ERROR:", "[" + ScriptName + "]: " + casterToSo + " was not called by the bot. (Reason: Command was in global cooldown)")
            elif castersAllow[pos] == False:
                msgToSend = "/me [" + ScriptName + "]: I am not allowed to shout out " + casterToSo + ". Permission deined by " + Parent.GetChannelName() + "."
                Parent.SendStreamWhisper (user, msgToSend)
                logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " to ShoutOut " + casterToSo + "\n"
                logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR:" + casterToSo + " could not be called by the bot. (Reason: "+ casterToSo +" is not allowed to be called by the bot)\n"
                if printLog:
                    Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " to ShoutOut " + casterToSo)
                    Parent.Log("ERROR:", "[" + ScriptName + "]: " + casterToSo + " could not be called by the bot. (Reason: " + casterToSo +" is not allowed to be called by the bot)")
        else:
            msgToSend = "/me [" + ScriptName + "]: " + casterToSo +" is not saved on the casters file for " + Parent.GetChannelName() + "."
            Parent.SendStreamWhisper(user, msgToSend)
            logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " to ShoutOut " + casterToSo + "\n"
            logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR:" + cmd + " could not be executed. (Reason: Non existent caster in the casters file)\n"
            if printLog:
                Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " to ShoutOut " + casterToSo)
                Parent.Log("ERROR:", "[" + ScriptName + "]: " + cmd + " could not be executed. (Reason: Non existent caster in the casters file)")
    else:
        msgToSend = "/me [" + ScriptName + "]: You need to specify the caster to be called."
        Parent.SendStreamWhisper(user, msgToSend)
        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " with no arguments.\n"
        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR:" + cmd + " could not be executed. (Reason: Missing arguments)\n"
        if printLog:
            Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " with no arguments.")
            Parent.Log("ERROR:", "[" + ScriptName + "]: " + cmd + " could not be executed. (Reason: Missing arguments)")
    if not (Parent.HasPermission(user, "Moderator", "") or Parent.HasPermission(user, "VIP Exclusive", "")):
        msgToSend = "/me [" + ScriptName + "]: You dont have premission to perform this action."
        Parent.SendStreamWhisper(user, msgToSend)
        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " shoutout a caster\n"
        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR:" + user + " tried to shoutout a caster with no success. (Reason: Missing permisions)\n"
        if printLog:
            Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " to shout out a caster")
            Parent.Log("ERROR:", "[" + ScriptName + "]: "+ user + " tried to shoutout a caster with no success. (Reason: Missing permisions)")
    return

def Add(source, user, cmd, message):
    global logMessage, printLog, castersList, castersFile, castersTwHandle
    entry = []
    for word in message.Split(" "):
        entry.append(word)
    params = len(entry) -1
    if Parent.HasPermission(user, "Editor", ""):
        if params == 0:
            msgToSend = "/me [" + ScriptName + "]: You need to specify which caster you want to add."
            Parent.SendStreamWhisper(user, msgToSend)
            logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " to add a caster with no arguments\n"
            logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR:" + cmd + " could not be executed. (Reason: Missing required arguments)\n"
            if printLog:
                Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " with no arguments.")
                Parent.Log("ERROR:", "[" + ScriptName + "]: " + cmd + " could not be executed. (Reason: Missing arguments)")
        elif params >= 1:
            casterToAdd = Parent.GetDisplayName(RemovePound(entry[1]))
            if casterToAdd.lower() not in castersTwHandle:
                if params == 1:
                    infoToAdd = {"twHandle": casterToAdd, "chatMsg": "Default", "allow": True}
                    castersList.casters.append(infoToAdd)
                    msgToSend = "/me [" + ScriptName + "]: " + casterToAdd + " was saved in casters file using the default message."
                    Parent.SendStreamWhisper(user, msgToSend)
                    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " to add "+ casterToAdd + " using the default message\n"
                    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO:" + casterToAdd + " was added to your casters file, associated to this message: \"" + defaultShoutOutMsg + "\"\n"
                    if printLog:
                        Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " to add " + casterToAdd + " using the default message.")
                        Parent.Log("INFO:", "[" + ScriptName + "]: " + casterToAdd + " was added to your casters file, associated to this message: \"" + defaultShoutOutMsg + "\"")
                elif params > 1:
                    casterMsg = []
                    for i in range(2, len(entry)):
                        casterMsg.append(entry[i])
                    if ChkMsg(casterMsg) == True:
                        msgToAdd = ""
                        for i in range(0, len(casterMsg)):
                            msgToAdd += casterMsg[i] + " "
                        msgToAdd = msgToAdd[:-1]
                        infoToAdd = {
                            "twHandle": casterToAdd,
                            "chatMsg": msgToAdd,
                            "allow": True
                        }
                        castersList.casters.append(infoToAdd)
                        msgToSend = "/me [" + ScriptName + "]: " + casterToAdd + " was saved in casters file using " + msgToAdd + " as custom message."
                        Parent.SendStreamWhisper(user, msgToSend)
                        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " to add " + entry[1] + " using a custom message\n"
                        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO:" + entry[1] + " was added to your casters file, associated to this message: \"" + msgToAdd + "\"\n"
                        if printLog:
                            Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " to add " + entry[1] + " using a custom message.")
                            Parent.Log("INFO:", "[" + ScriptName + "]: " + entry[1] + " was added to your casters file, associated to this message: \"" + msgToAdd + "\"")
                    else:
                        msgToSend = '/me [' + ScriptName + "]: Incorrect sintax. You need to add {caster} , {url} on your message. You can also add the optional parameter {game}."
                        Parent.SendStreamWhisper(user, msgToSend)
                        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " to add " + entry[1] + " using a custom message with no success\n"
                        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR:" + entry[1] + " could not be added. (Reason: Wrong sintax defined in custom message)\n"
                        if printLog:
                            Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " to add " + entry[1] + " using a custom message with no success")
                            Parent.Log("ERROR:", "[" + ScriptName + "]: " + entry[1] + " could not be added. (Reason: Wrong sintax defined in custom message)")
            else:
                msgToSend = "/me [" + ScriptName + "]: You are trying to add someone that already exists in the casters file. Please try deleting or editing " + casterToAdd + "'s info."
                Parent.SendStreamWhisper(user, msgToSend)
                logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " to add " + casterToAdd + " using the default message\n"
                logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR:" + casterToAdd + " could not be added to casters file. (Reason: " + casterToAdd + " is already saved)\n"
                if printLog:
                    Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " to add " + casterToAdd + " using the default message.")
                    Parent.Log("ERROR:", "[" + ScriptName + "]: " + casterToAdd + " could not be added to casters file. (Reason: " + casterToAdd + " is already saved)")
        UpdateCasters()
    if not Parent.HasPermission(user, "Editor", ""):
        msgToSend = "/me [" + ScriptName + "]: You dont have premission to perform this action."
        Parent.SendStreamWhisper(user, msgToSend)
        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " to add " + casterToAdd + " to your casters file\n"
        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR:" + user + " tried to add a caster with no success. (Reason: Missing permisions)\n"
        if printLog:
            Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " to add " + casterToAdd + " to your casters file")
            Parent.Log("ERROR:", "[" + ScriptName + "]: "+ user + " tried to add a caster with no success. (Reason: Missing permisions)")
    return

def Edit(source, user, cmd, message):
    global logMessage, printLog, castersList, castersFile
    opts = ['name', 'msg', 'allow']
    entry = []
    for word in message.Split(" "):
        entry.append(word)
    params = len(entry) - 1
    if Parent.HasPermission(user, "Editor", ""):
        if params == 0:
            msgToSend = "/me [" + ScriptName + "]: You need to specify a caster to edit. Check the help file for information on how to use this command."
            Parent.SendStreamWhisper(user, msgToSend)
            logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " to edit a caster with no arguments\n"
            logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR:" + cmd + " could not be executed. (Reason: Missing required arguments)\n"
            if printLog:
                Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " with no arguments.")
                Parent.Log("ERROR:", "[" + ScriptName + "]: " + cmd + " could not be executed. (Reason: Missing arguments)")
        elif params >= 1:
            casterToEdit = Parent.GetDisplayName(RemovePound(entry[1]))
            if casterToEdit.lower() not in castersTwHandle:
                msgToSend = "/me [" + ScriptName + "]: The caster you want to edit is non existent in the casters file. Try adding this caster before editing it."
                Parent.SendStreamWhisper(user, msgToSend)
                logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " to edit a non existent caster\n"
                logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR:" + cmd + " could not be executed. (Reason: Non existent caster in the casters file)\n"
                if printLog:
                    Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " to edit a non existent caster.")
                    Parent.Log("ERROR:", "[" + ScriptName + "]: " + cmd + " could not be executed. (Reason: Non existent caster in the casters file)")
            else:
                if params == 1 or params == 2:
                    msgToSend = "/me [" + ScriptName + "]: You need to specify what you want to edit from " + casterToEdit + " followed by the new value."
                    Parent.SendStreamWhisper(user, msgToSend)
                    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " to edit a caster without specifying what to change on the caster entry\n"
                    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR:" + cmd + " could not be executed. (Reason: Missing required arguments)\n"
                    if printLog:
                        Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " to edit a caster without specifying what to change on the caster entry.")
                        Parent.Log("ERROR:", "[" + ScriptName + "]: " + cmd + " could not be executed. (Reason: Missing required arguments)")
                elif params > 2:
                    if entry[2].lower() not in opts:
                        msgToSend = "/me [" + ScriptName + "]: The information you want to change is invalid. Possible changes to " + casterToEdit + "'s info are NAME, MSG or ALLOW."
                        Parent.SendStreamWhisper(user, msgToSend)
                        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " to edit a caster using wrong arguments\n"
                        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR:" + cmd + " could not be executed. (Reason: Wrong arguments)\n"
                        if printLog:
                            Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " to edit a caster without using wrong arguments.")
                            Parent.Log("ERROR:", "[" + ScriptName + "]: " + cmd + " could not be executed. (Reason: Wrong arguments)")
                    elif entry[2].lower() == opts[0] and params == 3:
                        NewHandle(casterToEdit, entry[3])
                        msgToSend = "/me [" + ScriptName + "]: " + casterToEdit + " name was changed to " + entry[3] + " successfuly."
                        Parent.SendStreamWhisper(user, msgToSend)
                        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " to edit a caster name\n"
                        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: Caster name was changed from " + casterToEdit + " to " + entry[3] + "\n"
                        if printLog:
                            Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " to edit a caster name.")
                            Parent.Log("INFO:", "[" + ScriptName + "]: Caster name was changed from " + casterToEdit + " to " + entry[3] + ".")
                    elif entry[2].lower() == opts[1]:
                        casterMsg = []
                        for i in range(3, len(entry)):
                            casterMsg.append(entry[i])
                        if ChkMsg(casterMsg) == True:
                            newMsg = ""
                            for i in range(0, len(casterMsg)):
                                newMsg += casterMsg[i] + " "
                            newMsg = newMsg[:-1]
                            msgSet = True
                        elif  entry[3] == "Default":
                            newMsg = entry[3]
                            msgSet = True
                        else:
                            msgSet = False
                            msgToSend = '/me [' + ScriptName + "]: Incorrect sintax. Custom messages require {caster} and {url} on your message. You can also add the optional parameter {game}. You can also specify \"Default\" (without quotes) to display the default message."
                            Parent.SendStreamWhisper(user, msgToSend)
                            logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " to edit " + casterToEdit + "'s message with no success\n"
                            logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR:" + casterToEdit + " could not be edited. (Reason: Wrong sintax)\n"
                            if printLog:
                                Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " to edit " + casterToEdit + "'s message with no success")
                                Parent.Log("ERROR:", "[" + ScriptName + "]: " + casterToEdit + " could not be edited. (Reason: Wrong sintax)")
                        if msgSet:
                            NewMessage(casterToEdit, newMsg)
                            msgToSend = "/me [" + ScriptName + "]: " + casterToEdit + " message was changed to " + newMsg + " successfuly."
                            Parent.SendStreamWhisper(user, msgToSend)
                            logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " to edit a caster message\n"
                            logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: Caster message was changed from " + casterToEdit + " to \"" + newMsg + "\"\n"
                            if printLog:
                                Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " to edit a caster message.")
                                Parent.Log("INFO:", "[" + ScriptName + "]: Caster message was changed from " + casterToEdit + " to \"" + newMsg + "\".")
                    elif entry[2].lower() == opts[2] and params == 3:
                        if entry[3].lower() == "yes" or entry[3].lower() == "no":
                            NewAllow(casterToEdit, entry[3].lower())
                            msgToSend = "/me [" + ScriptName + "]: " + casterToEdit + " allow status was changed successfuly to " + entry[3] + "."
                            Parent.SendStreamWhisper(user, msgToSend)
                            logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " to edit a caster allow status\n"
                            logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: Caster allow status was changed from " + casterToEdit + " to \"" + entry[3] + "\"\n"
                            if printLog:
                                Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " to edit a caster allow satus.")
                                Parent.Log("INFO:", "[" + ScriptName + "]: Caster allow status was changed from " + casterToEdit + " to \"" + entry[3] + "\".")
                        else:
                            msgToSend = "/me [" + ScriptName + "]: " + casterToEdit + " allow status cannot be changed to " + entry[3] + ". Use either \"YES\" or \"NO\" (without quotes) in order to change this."
                            Parent.SendStreamWhisper(user, msgToSend)
                            logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " to edit " + casterToEdit + "'s allow status with no success\n"
                            logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR:" + casterToEdit + " could not be edited. (Reason: Invalid value entry)\n"
                            if printLog:
                                Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " to edit " + casterToEdit + "'s message with no success")
                                Parent.Log("ERROR:", "[" + ScriptName + "]: " + casterToEdit + " could not be edited. (Reason: Invalid value entry)")
                    elif (entry[2].lower() == opts[0] or entry[2].lower() == opts[2]) and params > 3:
                        msgToSend = "/me [" + ScriptName + "]: " + entry[2] + " option requires only one parameter and you provided more than the required. No action was taken due to excessive parameters count."
                        Parent.SendStreamWhisper(user, msgToSend)
                        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " to edit " + casterToEdit + "'s message with no success\n"
                        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR:" + casterToEdit + " could not be edited. (Reason: Excessive parameters input)\n"
                        if printLog:
                            Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " to edit " + casterToEdit + "'s message with no success")
                            Parent.Log("ERROR:", "[" + ScriptName + "]: " + casterToEdit + " could not be edited. (Reason: Excessive parameters input)")
    if not Parent.HasPermission(user, "Editor", ""):
        msgToSend = "/me [" + ScriptName + "]: You dont have premission to perform this action."
        Parent.SendStreamWhisper(user, msgToSend)
        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " to edit " + casterToEdit + " in your casters file\n"
        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR:" + user + " tried to edit a caster with no success. (Reason: Missing permisions)\n"
        if printLog:
            Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " to edit " + casterToEdit + " in your casters file")
            Parent.Log("ERROR:", "[" + ScriptName + "]: "+ user + " tried to edit a caster with no success. (Reason: Missing permisions)")
    return

def Delete(source, user, cmd, message):
    global logMessage, printLog, castersList, castersFile
    entry = []
    for word in message.Split(" "):
        entry.append(word)
    params = len(entry) - 1
    if Parent.HasPermission(user, "Editor", ""):
        if params == 0:
            msgToSend = "/me [" + ScriptName + "]: No action was taken because no caster was specified."
            Parent.SendStreamWhisper(user, msgToSend)
            logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " to delete a caster from your casters file\n"
            logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR:" + user + " tried to delete a caster with no success. (Reason: Missing arguments)\n"
            if printLog:
                Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " to delete a caster from your casters file")
                Parent.Log("ERROR:", "[" + ScriptName + "]: "+ user + " tried to delete a caster with no success. (Reason: Missing arguments)")
        elif params >= 1:
            casterToDelete = Parent.GetDisplayName(RemovePound(entry[1]))
            if casterToDelete.lower() not in castersTwHandle:
                msgToSend = "/me [" + ScriptName + "]: The caster you want to delete is non existent in the casters file."
                Parent.SendStreamWhisper(user, msgToSend)
                logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " to delete a non existent caster\n"
                logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR:" + cmd + " could not be executed. (Reason: Non existent caster in the casters file)\n"
                if printLog:
                    Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " to delete a non existent caster.")
                    Parent.Log("ERROR:", "[" + ScriptName + "]: " + cmd + " could not be executed. (Reason: Non existent caster in the casters file)")
            else:
                if params == 1:
                    pos = pos = castersTwHandle.index(casterToDelete.lower())
                    del castersList.casters[pos]
                    UpdateCasters()
                    msgToSend = "/me [" + ScriptName + "]: " + casterToDelete + " was removed from casters file."
                    Parent.SendStreamWhisper(user, msgToSend)
                    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " to delete " + casterToDelete + "\n"
                    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO:" + casterToDelete + " was deleted from your casters file\n"
                    if printLog:
                        Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " to delete " + casterToDelete)
                        Parent.Log("INFO:", "[" + ScriptName + "]: " + casterToDelete + " was deleted from your casters file")
                elif params > 1:
                    msgToSend = "/me [" + ScriptName + "]: " + cmd + " requires only one parameter and you provided more than the required. No action was taken due to excessive parameters count."
                    Parent.SendStreamWhisper(user, msgToSend)
                    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " to delete " + casterToDelete + " with no success\n"
                    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR:" + casterToDelete + " could not be deleted (Reason: Excessive parameters input)\n"
                    if printLog:
                        Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " to delete " + casterToDelete + " with no success")
                        Parent.Log("ERROR:", "[" + ScriptName + "]: " + casterToDelete + " could not be deleted (Reason: Excessive parameters input)")
    if not Parent.HasPermission(user, "Editor", ""):
        msgToSend = "/me [" + ScriptName + "]: You dont have premission to perform this action."
        Parent.SendStreamWhisper(user, msgToSend)
        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " to delete " + casterToDelete + " from your casters file\n"
        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR:" + user + " tried to delete a caster with no success. (Reason: Missing permisions)\n"
        if printLog:
            Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " to delete " + casterToDelete + " from your casters file")
            Parent.Log("ERROR:", "[" + ScriptName + "]: "+ user + " tried to delete a caster with no success. (Reason: Missing permisions)")
    return

def Check(source, user, cmd, message):
    global logMessage, printLog, castersList, castersFile
    opts = ['all', 'msg', 'allow']
    entry = []
    for word in message.Split(" "):
        entry.append(word)
    params = len(entry) - 1
    if Parent.HasPermission(user, "Moderator", ""):
        if params == 0:
            msgToSend = "/me [" + ScriptName + "]: No action was taken because no caster was specified."
            Parent.SendStreamWhisper(user, msgToSend)
            logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " to inspect a caster info from your casters file\n"
            logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR:" + user + " tried to inspect a caster info with no success. (Reason: Missing arguments)\n"
            if printLog:
                Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " to inspect a caster info from your casters file")
                Parent.Log("ERROR:", "[" + ScriptName + "]: "+ user + " tried to inspect a caster info with no success. (Reason: Missing arguments)")
        elif params >= 1:
            casterToInspect = Parent.GetDisplayName(RemovePound(entry[1]))
            if casterToInspect.lower() not in castersTwHandle:
                msgToSend = "/me [" + ScriptName + "]: The caster you want to inspect is non existent in the casters file."
                Parent.SendStreamWhisper(user, msgToSend)
                logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " to inspect a non existent caster\n"
                logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR:" + cmd + " could not be executed. (Reason: Trying to inspect a non existent caster in the casters file)\n"
                if printLog:
                    Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " to inspect a non existent caster.")
                    Parent.Log("ERROR:", "[" + ScriptName + "]: " + cmd + " could not be executed. (Reason: Trying to inspect a non existent caster in the casters file)")
            else:
                if params == 1 or params == 2:
                    if params == 1:
                        msgToSend = Info(casterToInspect, "")
                        Parent.SendStreamMessage("/me ["+ ScriptName +"]: @"+ user +" , the result to your request was sent on your whisper...")
                        Parent.SendStreamWhisper(user, msgToSend)
                        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " to inspect information(s)" + casterToInspect + "\n"
                        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO:" + casterToInspect + "'s requested info was sent to " + user + "\n"
                        if printLog:
                            Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " to inspect " + casterToInspect)
                            Parent.Log("INFO:", "[" + ScriptName + "]: " + casterToInspect + "'s requested info was sent to " + user)
                    elif params == 2 and entry[2].lower() in opts:
                        msgToSend = Info(casterToInspect, entry[2].lower())
                        Parent.SendStreamMessage("/me ["+ ScriptName +"]: @"+ user +" , the result to your request was sent on your whisper...")
                        Parent.SendStreamWhisper(user, msgToSend)
                        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " to inspect information(s)" + casterToInspect + "\n"
                        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO:" + casterToInspect + "'s requested info was sent to " + user + "\n"
                        if printLog:
                            Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " to inspect " + casterToInspect)
                            Parent.Log("INFO:", "[" + ScriptName + "]: " + casterToInspect + "'s requested info was sent to " + user)
                    elif params == 2 and entry[2] not in opts:
                        msgToSend = "/me [" + ScriptName + "]: No action was taken due to a wrong info to check. User either \"ALL\", \"MSG\", \"ALLOW\" (without quotes) or don't specify what to inspect."
                        Parent.SendStreamWhisper(user, msgToSend)
                        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " to inspect information(s)" + casterToInspect + "\n"
                        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR:" + casterToInspect + " info request was not excecuted. (Reason: " + entry[2] + " is not avialable)\n"
                        if printLog:
                            Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " to inspect information(s)" + casterToInspect)
                            Parent.Log("ERROR:", "[" + ScriptName + "]: " + casterToInspect + " info request was not excecuted. (Reason: " + entry[2] + " is not avialable)")
                elif params > 2:
                    msgToSend = "/me [" + ScriptName + "]: " + cmd + " requires maximum of two parameters and you provided more than the required. No action was taken due to excessive parameters count."
                    Parent.SendStreamWhisper(user, msgToSend)
                    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " to inspect " + casterToInspect + "'s info with no success\n"
                    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR:" + casterToInspect + "'s info request was not executed. (Reason: Excessive parameters input) \n"
                    if printLog:
                        Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " to inspected " + casterToInspect + " with no success")
                        Parent.Log("ERROR:", "[" + ScriptName + "]: " + casterToInspect + "'s info request was not executed. (Reason: Excessive parameters input)")
    if not Parent.HasPermission(user, "Moderator", ""):
        msgToSend = "/me [" + ScriptName + "]: You dont have premission to perform this action."
        Parent.SendStreamWhisper(user, msgToSend)
        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND:" + user + " used " + cmd + " to check " + casterToInspect + "'s info from your casters files\n"
        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR:" + user + " tried to inspect a caster info with no success. (Reason: Missing permisions)\n"
        if printLog:
            Parent.Log("COMMAND:", "[" + ScriptName + "]: " + user + " used " + cmd + " to inspect " + casterToInspect + "'s info from your casters files")
            Parent.Log("ERROR:", "[" + ScriptName + "]: "+ user + " tried to inspect a caster info with no success. (Reason: Missing permisions)")
    return

def Info(name, arg):
    global castersList, castersTwHandle, castersChatMsg, castersAllow
    pos = castersTwHandle.index(name.lower())
    name = castersTwHandle[pos]
    msg = castersChatMsg[pos]
    if castersAllow[pos] == True:
        allow = "will"
    elif castersAllow[pos] == False:
        allow = "will not"
    if arg == "" or arg.lower() == "all":
        message = name + " " + allow + " be called by " + manualShoutCommand + " with the message: \"" + msg + "\" ."
    elif arg.lower() == "msg":
        message = name + "'s message is set to: \"" + msg + "\""
    elif arg.lower() == "allow":
        message = name + " " + allow + " be called by " + manualShoutCommand + " ."
    return message

def ChkMsg(msg):
    msgToChk = msg
    if ("{caster}" in msgToChk and "{url}" in msgToChk) or ("{caster}" in msgToChk and "{url}" in msgToChk and "{game}" in msgToChk):
        chkd = True
    else:
        chkd = False
    return chkd

def NewHandle(name, newValue):
    global logMessage, printLog, castersList
    pos = castersTwHandle.index(name.lower())
    castersList.casters[pos]['twHandle'] = newValue
    UpdateCasters()
    return

def NewMessage(name, newValue):
    global logMessage, printLog, castersList
    pos = castersTwHandle.index(name.lower())
    castersList.casters[pos]['chatMsg'] = newValue
    UpdateCasters()
    return

def NewAllow(name, newValue):
    global logMessage, printLog, castersList
    pos = castersTwHandle.index(name.lower())
    if newValue == "yes":
        setVal = True
    elif newValue == "no":
        setVal = False
    castersList.casters[pos]['allow'] = setVal
    UpdateCasters()
    return

def UpdateCasters():
    global castersList, castersTwHandle, castersChatMsg, castersAllow
    castersTwHandle = []
    castersChatMsg = []
    castersAllow = []
    castersList.Save(castersFile)
    castersList = Casters(castersFile)
    for item in castersList.casters:
        castersTwHandle.append(item['twHandle'].lower())
        castersChatMsg.append(item['chatMsg'])
        castersAllow.append(item['allow'])
    return

def RemovePound(name):
    if name[0] == "@":
        newName = name[1:]
    else:
        newName = name
    return newName

def CheckRaid(data):
    global raiderName, wasRaided, userNotice, reUserNotice, viewerCount
    reUserNotice = re.compile(r"(?:^(?:@(?P<irctags>[^\ ]*)\ )?:tmi\.twitch\.tv\ USERNOTICE)")
    userNotice = reUserNotice.search(data)
    if userNotice:
        tags = dict(re.findall(r"([^=]+)=([^;]*)(?:;|$)", userNotice.group("irctags")))
        id = tags['msg-id']
        if (id == 'raid'):
            displayName = tags['msg-param-displayName']
            viewerCount = tags['msg-param-viewerCount']
            if int(viewerCount) >= minRaidersToShout:
                raiderName = displayName
            wasRaided = True
    else:
        wasRaided = False
    return wasRaided

def ShoutCaster(name):
    global logMessage, casterShout
    casterToSo = name
    if casterToSo in castersTwHandle:
        pos = castersTwHandle.index(casterToSo)
        if castersAllow[pos] == True:
            url = "http://twitch.tv/" + casterToSo.lower()
            jsonData = json.loads(Parent.GetRequest("https://decapi.me/twitch/game/" + casterToSo, {}))
            game = jsonData["response"]
            if bool(castersChatMsg[pos] != "Default"):
                msgToSend = "/me " + castersChatMsg[pos].format(caster = casterToSo, url = url, game = game)
            else:
                msgToSend = "/me " + defaultShoutOutMsg.format(caster = casterToSo, url = url, game = game)
            Parent.SendStreamMessage(msgToSend)
            logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO:" + casterToSo + " was called by the bot using the AutoShoutout function!\n"
            if printLog:
                Parent.Log("INFO:", "[" + ScriptName + "]: " + casterToSo + " was called by the bot using the AutoShoutout function!")
            casterShout = True
        elif castersAllow[pos] == False:
            casterShout = False
    return casterShout

def ShoutRaider(name):
    global logMessage, castersShout
    casterToSo = name.lower()
    if casterToSo not in castersShout:
        url = "http://twitch.tv/" + casterToSo.lower()
        jsonData = json.loads(Parent.GetRequest("https://decapi.me/twitch/game/" + casterToSo, {}))
        game = jsonData["response"]
        msgToSend = "/me " + shoutRaiderMessage.format(raider = casterToSo, url = url, game = game, count = viewerCount)
        Parent.SendStreamMessage(msgToSend)
        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO:" + casterToSo + " raided you and was called by the bot using the AutoShoutout function!\n"
        if printLog:
            Parent.Log("INFO:", "[" + ScriptName + "]: " + casterToSo + " raided you and was called by the bot using the AutoShoutout function!")
        castersShout.append(casterToSo)
    return

def AddRaider():
    global logMessage, castersList
    raiderToAdd = Parent.GetDisplayName(raiderName)
    raiderMsgToAdd = "Default"
    raiderLastRaid = time.strftime("%Y/%m/%d@%H:%M:%S")
    raiderLastViewers = viewerCount
    infoToAdd = {
        "twHandle": raiderToAdd,
        "chatMsg": raiderMsgToAdd,
        "lastRaid": raiderLastRaid,
        "lastViewers": raiderLastViewers,
        "allow": True
    }
    castersList.casters.append(infoToAdd)
    UpdateCasters()
    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: " + raiderToAdd + " was saved to your casters file\n"
    if printLog:
        Parent.Log("INFO:", "[" + ScriptName + "]: " + raiderToAdd + " was saved to your casters file")
    return

def UpdateRaider():
    global logMessage, castersList
    pos = castersTwHandle.index(raiderName.lower())
    raiderNewLasRaid = time.strftime("%Y/%m/%d@%H:%M:%S")
    raiderNewLastViewers = viewerCount
    castersList.casters[pos]['lastRaid'] = raiderNewLasRaid
    castersList.casters[pos]['lastViewers'] = raiderNewLastViewers
    UpdateCasters()
    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: " + raiderToAdd + " information was updated on your casters file\n"
    if printLog:
        Parent.Log("INFO:", "[" + ScriptName + "]: " + raiderToAdd + " information was updated on your casters file")
    return

#---------------------------------------
# SetDefaults Custom User Interface Button
#---------------------------------------
def ShowCasters():
	global castersList
	if len(castersList.casters) == 0:
		Parent.Log("INFO:", "[" + ScriptName + "]: Your casters list is empty!")
	else:
		Parent.Log("INFO:", "[" + ScriptName + "]: Saved casters:")
		Parent.Log("FORMAT:", "Caster handle: <msg> - allowed status: <status>")
        for item in castersList.casters:
            Parent.Log("", item["twHandle"] + ": \"" + item["chatMsg"] + "\" - allowed status: " + str(item['allow']))
	return

def DeleteAllCasters():
    global logMessage, confirmation 
    confirmation = delAllCasters
    if confirmation:
        if createBackup:
            copy(castersFile, castersBackup)
        castersList.casters = []
        UpdateCasters()
        confirmation = ""
        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: \"Reset Casters File\" button was pressed\n"
        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: Casters file was cleared\n"
        if printLog:
            Parent.Log("COMMAND:", "[" + ScriptName + "]: \"Reset Casters File\" button was pressed")
            Parent.Log("INFO:", "[" + ScriptName + "]: Casters file was cleared")
    else:
        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: \"Reset Casters File\" button was pressed\n"
        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR: Casters file could not be cleared. (Reason: Confirmation to reset is required)\""
        if printLog:
            Parent.Log("COMMAND:", "[" + ScriptName + "]: \"Reset Casters File\" button was pressed")
            Parent.Log("ERROR:", "[" + ScriptName + "]: Casters file could not be cleared. (Reason: Confirmation to reset is required)")
    return

def LogFile():
    global logFileName, logDir, fileSaved, logMessage
    logMessage += "=========\n"
    logMessage += "This is the end of the Log file.\n"
    location = os.path.join(os.getcwd(), logDir)
    if not fileSaved:
        try:
            f = open(location + "\\" + logFileName, "w+")
            f.write(logMessage)
            f.close()
            fileSaved = True
            Parent.Log("INFO:", "[" + ScriptName + "]: Log file saved successfully!")
        except:
            fileSaved = False
            Parent.Log("ERROR:", "[" + ScriptName + "]:  Unable to save Log file. (Reason: Unknown)")
    elif fileSaved:
        Parent.Log("ERROR:", "[" + ScriptName + "]: Unable to save log file. (Reason: Logfile was aready saved by clicking this button.)")
    return fileSaved

def TestRaider():
    global castersShout, castersTwHandle, logMessage, printLog
    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: \"Test Raider AutoSO Settings\" button was pressed\n"
    if printLog:
        Parent.Log("COMMAND:", "[" + ScriptName + "]: \"Test Raider AutoSO Settings\" button was pressed")
    data = "@msg-id=raid;msg-param-displayName="+ Parent.GetChannelName() +";msg-param-viewerCount=" + str(Parent.GetRandom(minRaidersToShout, minRaidersToShout + 100)) + "; :tmi.twitch.tv USERNOTICE #" + Parent.GetChannelName()
    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: Sending request to test Raider AutoSO settings...\n"
    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: The output for this request will be displayed on your StreamChat and/or in the Chat Console from the bot\n"
    if printLog:
        Parent.Log("INFO:", "[" + ScriptName + "]: Sending request to test Raider AutoSo settings...")
        Parent.Log("INFO:", "[" + ScriptName + "]: The output for this request will be displayed on your StreamChat and/or in the Chat Console from the bot")
    CheckRaid(data)
    if raiderName.lower() in castersShout:
        castersShout.remove(raiderName.lower())
    if wasRaided == True and autoShoutRaiders:
        ShoutRaider(raiderName)
        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: Raider was shout using the AutoSo settings with success\n"
        if printLog:
            Parent.Log("INFO:", "[" + ScriptName + "]: Raider was shout using the AutoSo settings with success")
    elif not (wasRaided == True and autoShoutRaiders):
        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR: Unable to test AutoSO settings. (Reason: AutoSO Raider setting is not enabled)\n"
        if printLog:
            Parent.Log("ERROR:", "[" + ScriptName + "]: Unable to test AutoSO settings. (Reason: AutoSO Raider setting is not enabled)")
    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: Sending request to test Raider saving to your casters file...\n"
    logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: The output for this request will be as a new caster named " + Parent.GetChannelName() +" on your casters file\n"
    if printLog:
        Parent.Log("INFO:", "[" + ScriptName + "]: Sending request to test Raider saving to your casters file...")
        Parent.Log("INFO:", "[" + ScriptName + "]: The output for this request will be as a new caster named " + Parent.GetChannelName() +" on your casters file")
    if addRaidersToCaster:
        if raiderName.lower() not in castersTwHandle:
            AddRaider()
            logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: Test Raider was added to your casters file with success\n"
            if printLog:
                Parent.Log("INFO:", "[" + ScriptName + "]: Test Raider was added to your casters file with success")
        elif raiderName.lower() in castersTwHandle:
            UpdateRaider()
            logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: Test Raider info is already inside the casters file and was updated with success\n"
        if printLog:
            Parent.Log("INFO:", "[" + ScriptName + "]: Test Raider info is already inside the casters file and was updated with success")
    elif not addRaidersToCaster:
        logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR: Unable test autosave Test Raider. (Reason: AutoSave Raider setting is not enabled)\n"
        if printLog:
            Parent.Log("ERROR:", "[" + ScriptName + "]: Unable test autosave Test Raider. (Reason: AutoSave Raider setting is not enabled)")
    return



def OpenLogDir():
    location = logDir
    os.startfile(os.path.join(os.getcwd(), location))
    

def ReadMeFile():
    location = os.path.join(os.path.dirname(__file__), "CustomShoutOut_ReadMe.txt")
    os.startfile(location)

def ChangesFile():
    location = os.path.join(os.path.dirname(__file__), "CustomShoutOut_Changelog.txt")
    os.startfile(location)

def OpenWebSite():
	os.startfile(Website)
