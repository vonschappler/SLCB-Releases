Instructions of Usage:

This is a small help file to allow users to setup this script correctly. It's
needless to say that this script has (I would say) a deep Log system (as my other
scripts) and most of the messages outputs are sent to the user whisper.
In order to make it able for users to know if changes are being aplied when using
certain commands, it's REQUIRED that they have your bot added to their friends list
if they have whispers blocked.

================================================================================
NOTE: ANY CHANGES TO THE INFORMATION PROVIDED IN THE SCRIPT UI WILL TAKE EFFECT
      ONLY AFTER THE BUTTON "SAVE SETTINGS" IS CLICKED. TO ENSURE YOUR SETTINGS
      WERE SAVED, WE ADVISE TO CLICK THIS BUTTON AT LEAST TWO TIMES.
      ALSO KEEP IN MIND THAT SETTINGS CHANGED WITH COMMANDS WON'T BE SAVED TO
      YOUR SETTINGS.
================================================================================
Let's now take a quick look on how you can use this script!

    a) Main Settings:
        a.1) Auto ShoutOut saved Casters?
            This feature will enable the Auto ShoutOut to casters you have saved
            on your casters file (casters.json), which will be detalled later
        a.2) ShoutOut when caster joins channel?
            If enabled, this feature will shoutout any saved casters at the moment
            they join your channel. If disabled, it will shout them just after they
            send any message on your chat.
        a.3) Auto ShoutOut raider?
            This feature will auto shoutout raiders based on the settings defined on
            the next settings group.
    
    b) Shout Raiders Settings:
        b.1) Message to use for ShoutOut raiders:
            Here you can set a custom message to be used when auto shout raiders is
            enabled. Keep in mind that for this to work correctly, you need to add to
            this message the following parameters:
            > {raider} - this will be replaced on the message by the raider name
            > {count} - this will be replaced on the message by the number or raiders
            > {url} - this will be replaced on the message by the raider Twitch url
                channel link
            > {game} - this will be replaced on the message by the raider last played
                game
            
            EXAMPLE OF WORKING MESSAGE:
            {raider} was playing {game} and just brought {count} viewers to our
                channel! Let's support them visiting {url} !
            
            NOTE: THE SCRIPT WILL CHECK FOR THE PARAMETERS IN THE MESSAGE USED WHEN SAVING
            UI/SCRIPT SETTINGS. SO FOR THE MESSAGE TO BE ACCEPTED BY THE SCRIPT, REMEMBER
            TO ALWAYS GIVE A BLANK SPACE AFTER THE REQUIRED PARAMETERS DETAILED ABOVE.
        b.2) Minimum raiders to Auto Shoutout raider:
            This is the minimum amount of raiders that will trigger the auto shoutout
            raider.
        b.3) Save raiders to caster file?
            If enabled, this will create (or update, in case the raider is already in
            your casters file) an entry with the raider (and basic raid) information.
            NOTE: IF THIS IS DISABLED AND YOU WANT TO GIVE THE RAIDER A SHOUTOUT BY USING
            THIS SCRIPT, YOU WILL NEED TO ADD THE RAIDER MANUALLY USING THE SPECIFIED
            COMMAND TO ADD A CASTER.
        b.4) Test Raider AutoSO settings
            This button will request the bot to simulate a raid, post the AutoSO message
            and will add a test raider to your casters file IF the options in a.3 and b.3
            are enabled.
            HONORABLE MENTION:
            THIS ESPECIFIC PART OF THE SCRIPIT IS AN IMPLEMENTATION OF THE SCRIPT "RAID
            NOTIFY" MADE BY Kruiser, WITH SOME SMALL CHANGES TO HIS ORIGINAL CODE IN ORDER
            TO FIT THE TESTING PURPOSE REQUIRED FOR THIS SCRIPT.
            
    c) ShoutOut Settings:
        c.1) Command for manual ShoutOut:
            This field is used to set the command to use for manual ShoutOuts if the AutoSO
            is disabled or if you see fit making extra ShoutOuts. This specific command will
            shoutout ONLY casters saved on your casters file.
            USAGE: 
                > !caster name
                > !caster @name
            (both usages shown above will work)
            ANSWER: 
                The bot will look for the entry of the caster specified by name and will
                post in the chat the message defined with info gathered from Twitch.
        c.2) Permission to use the command:
            This field is self explanative. Just users with the specified permission can
            use the command specified above.
        c.3) Default message for ShoutOuts:
            Similar to what was detailed in b.1, this field is used to set a message with
            some parameters:
            > {caster} - this will be replaced on the message by the caster name
            > {url} - this will be replaced on the message by the caster Twitch url
                channel link
            > {game} - this will be replaced on the message by the raider last played
                game (this is an optional parameter)
            
            EXAMPLE OF WORKING MESSAGE:
            Let's support my friend {caster} visiting their {url} ! They were playing 
                {game} on their last stream!
        c.4) Global cooldown (in seconds):
            Specifies a small cooldown to prevent span of the command if used by two
            or more permited users.

    d) Caster Control:
        This section is the root of the script. Here it's possible to set all the
        necessary commands to manage casters saved by this script.
        d.1) Command to add a new caster to AutoShoutOut:
            This is the command you and your editors will add new casters to your casters
            file. This was set like that so it will prevent mods to add casters without
            request/authorization. All casters added will ALWAYS be ShoutOut by the script,
            unless specified differently (this will be explained below).
            USAGE:
                > Adding a caster using the default message set in script:
                    !addcaster <casterName>
                > Adding a caster using a custom message:
                    !addcaster <casterName> <customMessage>
                (<customMessage> must follow the EXAMPLE OF WORKING MESSAGE detailed in c.3)
            ANSWER:
                The answer will depend on the usage of the command. Loging for this command
                is tracked by the script and also the replies of fail or success are sent
                to the user whisper.
        d.2) Command to edit information from a caster to AutoShouOut:
            With this command, you and your editors can change informations saved inside your
            saved casters file. Details that can be edited:
            > name - changes the name of previous saved casterName, in case you
                don't want to create a new entry with the command decribed above
            > msg - changes the msg set up to shoutout a saved caster
            > allow - changes the behave of the script to allow shouting out the caster or not
            USAGE:
                > Changing a caster name:
                    !setcaster <casterName> name <newCasterName>
                > Changing a caster message from "Default" to custom message:
                    !setcaster <casterName> msg <customMessage>
                (<customMessage> must follow the EXAMPLE OF WORKING MESSAGE detailed in c.3)
                > Changing a caster message from a custom message to default
                    !setcaster <casterName> msg Default
                (Default MUST BE WRITTEN with capital D)
                > Chaging the bot behavior to ShoutOuts:
                    !setcaster <casterName> allow yes (bot will shoutout <casterName>)
                    !setcaster <casterName> allow no (bot will not shoutout <casterName>)
            ANSWER:
                The answer provided by the script will depend on the changed information
                and will depend also if the change was accepted or not by the script.
                Those answers are sent on the whisper of the user.
        d.3) Command to delete a caster from AutoShoutOut:
            This command is used to delete a single caster saved to your casters file.
            USAGE:
                > !delcaster <casterName>
            ANSWER:
                The script will look out for <casterName> entry on your casters file and
                delete it. If <casterName> is not found, no action will be taken and the
                answer for this command will depend on the fail or success of removal.
        d.4) Command to check info about a saved caster:
            This command is used to inspect the info saved in the casters file created with
            the infomation provided with all the above commands for a single caster.
            USAGE:
                > Checking all basic saved info:
                    !chkcaster <casterName> all
                > Checking the caster message:
                    !chkcaster <casterName> msg
                > Checking the caster bot behavior to shoutouts:
                    !chkcaster <casterName> allow
            ANSWER:
                The answer for this request will be sent to the user whisper and it will
                depends on what kind of requisition was made via command.
        d.5) List all saved Casters:
            Clicking this button will print in chatbot log section all the contents of
            your saved casters file.
        d.6) I am sure I wnat to reset my castes file:
            Enabling this is REQUIRED if you want to RESET your casters file.
        d.7) I want to creat a backup of current casters file:
            Enabling this is OPTIONAL. If enabled, it will make a copy of your current saved
            casters file into a new file with the extension *.bk (to mark is as backup).
            NOTE: IF THRE IS ALREADY A BACKUP FILE ON YOUR SCRIPT DIRECTORY, CHECKING THIS
            WILL REPLACE ALL THE CONTENTS OF THE BACKUP FILE!
        d.8) Reset casters file:
            This is self explanative and will work ONLY if d.6 is enabled.

    e) ScriptLog Settings:
        A mentioned before, the script "has a deep" log functionality and the behavior of
        these functions are controled here.
        e.1) Display Script log in the ChatBot?
            Enabling this will send all log information created by this script to your
            ChatbotLog console. Use this if you want to have control on what is being
            processed by the bot during it's usage.
        e.2) AutoSave ScriptLog file?
            Enabling this will make the script to save a file with the log of the last usage
            session everytime the script is reloaded or the bot is closed.
        e.3) Save ScriptLog file:
            Clicking here will prematurely save the script logs in the log file and will prevent
            the AutoSave to create a file if AutoSave is enabled.
            NOTE: CLICKING THIS BUTTON WILL ALSO PREVENT IT FROM BEING CLICKED AGAIN AND SAVING
            A NEW FILE. THIS IS A FEATURE TO BE "FIXED" IN FUTURE RELEASES.
        e.4) Open ScriptLog Directory:
            Clicking this button will open the directory where all the logs for this script are
            saved.
    
    f) Support:
        f.1 ) Visit my Site:
            Clicking this button will open your default browser and redirect to my personal
            website.
        f.2) Open ReadMe.txt:
            Clicking this button will open this document.
        f.3) Changelog:
            Clicking this button will open the "Changelog.txt" file with the changes made to
            the script.
        
    g) Save Settings:
        Clicking this button is required every time changes are made to the script UI in order
        to make them to be accepted by the script.


  I hope this script is useful and that you enjoy using it!

  Dont forget to check my website, by clicking the "Visit my Site" button and
  give me all support possible if you really wish to!

  Regards!

                                                   von_Schappler
