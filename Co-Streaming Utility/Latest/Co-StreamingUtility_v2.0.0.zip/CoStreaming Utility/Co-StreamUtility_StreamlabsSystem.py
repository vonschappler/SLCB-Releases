""" TO-DO List:
1. Check for unused variables
2. Create the code for commands to change the site manually
3. Test the updates """

#---------------------------------------
# Import Libraries
#---------------------------------------
import sys
import os
import codecs
import json
import time
import collections
sys.path.append(os.path.join(os.path.dirname(__file__), "Classes"))
import clr
clr.AddReference("IronPython.SQLite.dll")
clr.AddReference("IronPython.Modules.dll")
from SettingsClass import Settings
from collections import OrderedDict

#---------------------------------------
# Script Information
#---------------------------------------
ScriptName = "Co-Streaming Utility"
Website = "https://rebrand.ly/vonWebsite "
Description = "Co-Streaming utility for your stream."
Creator = "von_Schappler"
Version = "2.0.0"

#---------------------------------------
# Variables
#---------------------------------------
global settingsFile, scriptSettings, logoDir
global casterName, dispName, url, friends, game, coMsgToSend, isEnabled, directory
global logFileName, gameToShow, gameSet, fileSaved, printLog, autoLog, logMessage
global providersList, providersName, providersRef, providersUrl, friendsSet, urlSet, coOn
global coMsg, coFriends, coProvider, coCustom, coGame, setCoOn, setCoOff
global setCoGame, setCoProvider, coDisplay, coUserCD, coAutoCD, coAutoMsg
global printLog, autoLog
settingsFile = os.path.join(os.path.dirname(__file__), "settings.json")
providersFile = os.path.join(os.path.dirname(__file__), "providers.json")
uiFile = os.path.join(os.path.dirname(__file__), "UI_Config.json")
logDir = os.path.join(os.path.dirname(__file__), "Log")
scriptSettings = Settings(settingsFile)
isEnabled = True
coMsg = "/me : {caster} is currently Co-Streaming with {friends} at {url} ! Click the url to a co-view of {game}!"
coFriends = "caster1"
coProvider = "MultiTwitch_LIVE(id=1)"
coCustom = "example.provider"
coGame = "auto"
setCoOn = "!setcoon"
setCoOff = "!setcooff"
setCoGame = "!setcogame"
setCoProvider = "!setcosite"
coDisplay = "!costream"
coUserCD = 5.0
coAutoMsg = True
coAutoCD = 10
printLog = False
autoLog = True
friends = ""
friendsSet = False
url = ""
urlSet = False
coMsgToSend = ""
logFileName = "Co-StreamLog_"
gameToShow = ""
gameSet = False
fileSaved = False
providersName = []
providersRef = []
providersUrl = []
coOn = False

#---------------------------------------
# Initialize Data on Load
#---------------------------------------
def Init():
	global providersList, friends, coMsgToSend, coOn, casterName, selProvider, friendsList, game
	casterName = Parent.GetChannelName()
	if not os.path.exists(logDir):
		os.makedirs(logDir)
	try:
		with codecs.open(settingsFile, encoding="utf-8-sig", mode="r") as f:
			ReloadSettings(f.read())
	except:
		Parent.Log("ERROR: ", "[" + ScriptName + "]:  Unable to load settings during execution! (Init)")
	with codecs.open(providersFile, encoding="utf-8-sig", mode="r") as f:
		providersList = json.load(f, encoding="utf-8")
		for item in providersList['providers']:
			providersName.append(item['name'])
			providersRef.append(item['cmdref'])
			providersUrl.append(item['url'])
	with codecs.open(uiFile, encoding="utf-8-sig", mode="r") as f:
		data = json.load(f, encoding="utf-8", object_pairs_hook=OrderedDict)
	data['coProvider']['items'] = providersName
	data['coProvider']['value'] = providersName[0]
	friends = coFriends
	with codecs.open(uiFile, encoding="utf-8-sig", mode="w+") as f:
		json.dump(data, f, encoding="utf-8", indent=2)

	try:
		if (open(settingsFile)):
			if friendsSet == False and scriptSettings.coFriends != "":
				friendsList = scriptSettings.coFriends
				SetFriends(friendsList)
			if urlSet == False:
				selProvider = providersUrl[int(providersName.index(scriptSettings.coProvider))]
				if selProvider == "custom":
					if coCustom == "" or coCustom == "example.provider":
						selProvider = providersUrl[1]
						Parent.SendStreamWhisper(casterName,"/me : [" + ScriptName + "]: You chose to use a custom provider but haven't defined one. The url created will redirect to the default script provider: \"" + selProvider +"\". ")
				elif coCustom != "" or coCustom != "example.provider":
					selProvider = coCustom
				SetUrl(selProvider)
			if gameSet == False:
				game = scriptSettings.coGame
				SetGame(game)
			if friendsSet and urlSet and gameSet:
				coMsgToSend = scriptSettings.coMsg.format(caster = casterName, url = url[:-1], friends = friends[:-1], game = gameToShow)
				Parent.SendStreamWhisper(casterName, "/me : [" + ScriptName + "]: Co-Stream url was created automatically using last saved UI settings. Type !setcoon to start the script with the loaded settings. (url created: " + url + ")")
			elif not friendsSet or not urlSet or not gameSet:
				Parent.SendStreamWhisper(casterName, "/me : [" + ScriptName + "]: Unable to create Co-Stream url using last saved UI settings. Use the specified command with correct values to create a url manually.")
			return coOn
	except:
		Parent.SendStreamWhisper(casterName, "/me : [" + ScriptName + "]: Welcome! This is your first time using this script. To ensure its funcionalities, open the script UI and press \"Save Settings\"...")
	

#---------------------------
#   [Optional] Reload Settings (Called when a user clicks the Save Settings button in the Chatbot UI)
#---------------------------
def ReloadSettings(jsondata):
	global logFileName, logMessage, printLog, autoLog, coCustom, friendsList, friendsSet, url, urlSet, gameSet, coOn, coMsgToSend, coAutoCD
	scriptSettings.Reload(jsondata)
	casterName = Parent.GetChannelName()
	friendsList = ""
	url = ""
	friendsSet = False
	urlSet = False
	gameSet = False
	coMsg = scriptSettings.coMsg
	coFriends = scriptSettings.coFriends
	coProvider = scriptSettings.coProvider
	coCustom = scriptSettings.coCustom
	coGame = scriptSettings.coGame
	setCoOn = scriptSettings.setCoOn
	setCoOff = scriptSettings.setCoOff
	setCoGame = scriptSettings.setCoGame
	setCoProvider = scriptSettings.setCoProvider
	coDisplay = scriptSettings.coDisplay
	coUserCD = scriptSettings.coUserCD
	coAutoMsg = scriptSettings.coAutoMsg
	coAutoCD = scriptSettings.coAutoCD
	printLog = scriptSettings.printLog
	autoLog = scriptSettings.autoLog
	logFileName += time.strftime("%Y%m%d_%H%M%S") + ".log"
	logMessage = time.strftime("[%Y/%m/%d@%H:%M:%S]") + " This is the begin of the Log data for " + ScriptName + ":\n"
	logMessage += "=========\n"
	logMessage += "Last saved settings:\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Message to sent in chat with Co-Streaming url: " + str(coMsg) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Last UI saved friends: " + str(coFriends) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Preferred Co-Streaming provider: " + str(coProvider) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Custom Co-Streaming provider: " + str(coCustom) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Game played during Co-Streaming: " + str(coGame) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Command to set url for Co-Streaming: " + str(setCoOn) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Command to reset url for Co-Streaming: " + str(setCoOff) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Command to set game manually: " + str(setCoGame) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Command to set Co-Stream site manually: " + str(setCoProvider) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Command to display Co-Streaming url in chat: " + str(coDisplay) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: User cooldown between uses of Co-Streaming display command: " + str(coUserCD) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Allow the script to auto post Co-Stream url: " + str(coAutoMsg) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "SETTINGS: Time between auto Co-Streaming Messages: " + str(coAutoCD) + "\n"
	logMessage += "=========\n"
	if printLog == True:
		Parent.Log("INFO: ", time.strftime("(%Y/%m/%d - %H:%M:%S) ") + ScriptName + " last saved settings:")
		Parent.Log("SETTINGS: ", "[" + ScriptName + "]: Message to sent in chat with Co-Streaming url: " + str(coMsg))
		Parent.Log("SETTINGS: ", "[" + ScriptName + "]: Last UI saved friends: " + str(coFriends))
		Parent.Log("SETTINGS: ", "[" + ScriptName + "]: Preferred Co-Streaming provider: " + str(coProvider))
		Parent.Log("SETTINGS: ", "[" + ScriptName + "]: Custom Co-Streaming provider: " + str(coCustom))
		Parent.Log("SETTINGS: ", "[" + ScriptName + "]: Game played during Co-Streaming: " + str(coGame))
		Parent.Log("SETTINGS: ", "[" + ScriptName + "]: Command to set url for Co-Streaming: " + str(setCoOn))
		Parent.Log("SETTINGS: ", "[" + ScriptName + "]: Command to reset url for Co-Streaming: " + str(setCoOff))
		Parent.Log("SETTINGS: ", "[" + ScriptName + "]: Command to set game manually: " + str(setCoGame))
		Parent.Log("SETTINGS: ", "[" + ScriptName + "]: Command to set Co-Stream site manually: " + str(setCoProvider))
		Parent.Log("SETTINGS: ", "[" + ScriptName + "]: Command to display Co-Streaming url in chat: " + str(coDisplay))
		Parent.Log("SETTINGS: ", "[" + ScriptName + "]: User cooldown between uses of Co-Streaming display command: " + str(coUserCD))
		Parent.Log("SETTINGS: ", "[" + ScriptName + "]: Allow the script to auto post Co-Stream url: " + str(coAutoMsg))
		Parent.Log("SETTINGS: ", "[" + ScriptName + "]: Time between auto Co-Streaming Messages: " + str(coAutoCD))
	
	friendsList = scriptSettings.coFriends
	SetFriends(friendsList)
	selProvider = providersUrl[int(providersName.index(scriptSettings.coProvider))]
	if selProvider == "custom":
		if coCustom == "" or coCustom == "example.provider":
			selProvider = providersUrl[1]
			Parent.SendStreamWhisper(casterName,"/me : [" + ScriptName + "]: You chose to use a custom provider but haven't defined one. The url created will redirect to the default script provider: \"" + selProvider +"\". ")
		elif coCustom != "" or coCustom != "example.provider":
			selProvider = coCustom
	SetUrl(selProvider)
	game = scriptSettings.coGame
	SetGame(game)
	coMsgToSend = scriptSettings.coMsg.format(caster = casterName, url = url[:-1], friends = friends[:-1], game = gameToShow)
	Parent.SendStreamWhisper(casterName, "/me : [" + ScriptName + "]: Co-Streaming url was created or updated after saving UI settings. (url created: " + url + ")")
	return coMsgToSend
#	return

#---------------------------------------
#	Script is going to be unloaded
#---------------------------------------
def Unload():
	scriptSettings.Save(settingsFile)
	if not fileSaved and autoLog:
		LogFile()
	return

#---------------------------------------
#	Script is enabled or disabled on UI
#---------------------------------------
def ScriptToggled(state):
	global scriptSettings, isEnabled
	if not state:
		scriptSettings.Save(settingsFile)
		isEnabled = False
	else:
		isEnabled = True
	return isEnabled

#---------------------------------------
# Execute data and process messages
#---------------------------------------
def Execute(data):
	if data.IsChatMessage() and isEnabled:
		if data.IsFromTwitch():
			source = "twitch"
			Costream(source, data.User.lower(), data.GetParam(0), data.Message[len(data.GetParam(0)) + len(" "):])
		if data.IsFromDiscord():
			source = "discord"
			Costream(source, data.User.lower(), data.GetParam(0), data.Message[len(data.GetParam(0)) + len(" "):])
	return

#---------------------------------------
# Tick
#---------------------------------------
def Tick():
	global logMessage, coAutoCD
	if coAutoCD: 
		if coAutoMsg and not Parent.IsOnCooldown(ScriptName, "autoCo") and Parent.IsLive() and coOn:
			cd = coAutoCD * 60
			Parent.SendStreamMessage(coMsgToSend)
			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: the Co-Stream url was displayed in chat automatically\n"
			if printLog == True:
				Parent.Log("INFO: ", "[" + ScriptName + "]: Co-Stream url was displayed in chat automatically")
			Parent.AddCooldown(ScriptName, "autoCo", cd)
	return

#---------------------------------------
# Functions
#---------------------------------------
def Costream(source, user, message, args):
	global selProvider, coolDown, command, casterName, url, friends, coMsgToSend, logMessage, gameToShow, gameSet, friendsSet, coOn, friendsList, game, selProvider
	coolDown = scriptSettings.coUserCD * 60
	globalCD = 10
	command = message
	setCommands = [scriptSettings.setCoOn, scriptSettings.setCoOff, scriptSettings.setCoGame, scriptSettings.setCoProvider]
	showCommand = [scriptSettings.coDisplay]
	casterName = Parent.GetChannelName()
	source = source
	friendsList = scriptSettings.coFriends
	selProvider = providersUrl[int(providersName.index(scriptSettings.coProvider))]
	game = scriptSettings.coGame
	if Parent.HasPermission(user, "Moderator", ""):
		if command == setCommands[0]:
			if friendsSet and gameSet and urlSet:
				coMsgToSend = scriptSettings.coMsg.format(caster = casterName, url = url[:-1], friends = friends[:-1], game = gameToShow)
				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + "to create a Co-Stream url\n"
				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: Co-Stream url was created by " + user + " with success using UI saved parameters\n"
				if printLog == True:
					Parent.Log("INFO:", "[" + ScriptName + "]: Co-Stream url was created by " + user + " with success using UI saved parameters")
				coOn = True
			if (friendsSet and args != "") or (not friendsSet and args != ""):
				coMsgToSend = ""
				SetFriends(args)
				SetUrl(selProvider)
				coMsgToSend = scriptSettings.coMsg.format(caster = casterName, url = url[:-1], friends = friends[:-1], game = gameToShow)
				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + " to change casters to " + args + "\n"
				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: " + user + " changed casters with success\n"
				if printLog == True:
					Parent.Log("INFO:", "[" + ScriptName + "]: " + user + " changed casters with success to " + friends)
				coOn = True
			if (friendsSet and args == ""):
				if friendsList != "":
					Parent.SendStreamWhisper(user, "/me : [" + ScriptName + "]: no changes were made to previous created url because you didn't entered new arguments.")
					logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + " to change casters to " + args + "\n"
					logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: no changes were made to previous created url. \n"
					if printLog == True:
						Parent.Log("INFO:", "[" + ScriptName + "]: no changes weer made to previous created url.")
				elif friendsList == "":
					logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + " to change casters to " + args + "\n"
					logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR: " + user + " failed to add or update casters. Previous message was not changed. (Reason: Missing arguments)\n"
					if printLog == True:
						Parent.Log("ERROR:", "[" + ScriptName + "]: " + user + " failed to add or update casters. (Reason: Missing argurments)")
				coOn = True
			elif not friendsList and args == "":
				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + " to change casters to " + args + "\n"
				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR: " + user + " failed to create Co-Stream url.(Reason: Missing arguments)\n"
				if printLog == True:
					Parent.Log("ERROR:", "[" + ScriptName + "]: " + user + " failed to create Co-Stream url. (Reason: Missing argurments)")
				coOn = False
			if coOn == True:
				Parent.SendStreamWhisper(user, "/me : [" + ScriptName + "]: Co-Stream url is set correctly. Viewers can now type !co in chat to display this url: " + url + " where " + casterName + " is playing " + gameToShow)
			elif coOn == False:
				Parent.SendStreamWhisper(user, "/me : [" + ScriptName + "]: Failed to create or update Co-Stream url. Required info to create the url was not given. Type " + command + " followed by the names of casters to create the Co-Stream url, separated by a blank space, e.g.: " + command + " caster1 caster 2")
		if command == setCommands[1]:
			coMsgToSend = ""
			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + " to disable Co-Stream url\n"
			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: " + user + " has disabled Co-Stream url\n"
			if printLog == True:
				Parent.Log("INFO:", "[" + ScriptName + "]: " + user + " has disabled Co-Stream url")
			coOn = False
			Parent.SendStreamWhisper(user, "/me : [" + ScriptName + "]: Co-Stream url was disabled")
		if command == setCommands[2]:
			SetGame(args)
			coMsgToSend = scriptSettings.coMsg.format(caster = casterName, url = url[:-1], friends = friends[:-1], game = gameToShow)
			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + " to edit game to " + gameToShow + "\n"
			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: " + user + " has changed the game with success\n"
			if printLog == True:
				Parent.Log("INFO:", "[" + ScriptName + "]: "+ user + " has changed the game with success to " + gameToShow)
			Parent.SendStreamWhisper(user, "/me : [" + ScriptName + "]: Game was changed to "+ gameToShow)
		if command == setCommands[3]:
			entry = args.split(" ")
			if entry[0] in providersRef:
				if entry[0] == "0":
					if len(entry) == 1:
						selProvider = providersUrl[1]
						Parent.SendStreamWhisper(user, "/me : [" + ScriptName + "]: Because there is no custom provider set and you haven't entered any with this command, the url will be redirected to the last saved provider: \"" + selProvider + "\".")
					elif len(entry) == 2:
						selProvider = entry[1]
					elif len(entry) > 2:
						Parent.SendStreamWhisper(user, "/me [" + ScriptName + "]: Failed to change Co-Stream url. (Reason: Too many parameters)")
				else:
					selProvider = providersUrl[int(entry[0])]
				SetUrl(selProvider)
				coMsgToSend = scriptSettings.coMsg.format(caster = casterName, url = url[:-1], friends = friends[:-1], game = gameToShow)
				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + " to edit provider to " + selProvider + "\n"
				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: " + user + " has updated the url with success\n"
				if printLog == True:
					Parent.Log("INFO:", "[" + ScriptName + "]: "+ user + " has changed the url with success")
				Parent.SendStreamWhisper(user, "/me : [" + ScriptName + "]: Provider changed to " + selProvider +". Viewers can now type !co in chat to display this url: " + url + " where " + casterName + " is playing " + gameToShow)
			elif entry[0] == "" or entry[0] not in providersRef:
				selProvider = providersUrl[int(providersName.index(scriptSettings.coProvider))]
				SetUrl(selProvider)
				coMsgToSend = scriptSettings.coMsg.format(caster = casterName, url = url[:-1], friends = friends[:-1], game = gameToShow)
				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + " to edit provider\n"
				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR: " + user + " failed to update the url. Selected provider in UI remains. (Reason: No provider was given or an invidalid parameter was given by the user)\n"
				if printLog == True:
					Parent.Log("ERROR:", "[" + ScriptName + "]: "+ user + " failed to update the url. Selected provider in UI remains. (Reason: No provider was given or an invalid parameter was give by the user)")
				Parent.SendStreamWhisper(user, "/me : [" + ScriptName + "]: Provider change failed. Enter a valid parameter to change Co-Stream provider")
	elif not Parent.HasPermission(user, "Moderator", "") and command in setCommands:
		logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + "\n"
		logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR: " + user + " failed to use " + command + ". (Reason: "+ user + " lacks the required permission to use " + command + ")\n"
		if printLog == True:
			Parent.Log("ERROR:", "[" + ScriptName + "]: "+ user + " failed to use " + command + ". (Reason: "+ user + " lacks the required permission to use " + command + ")")
		Parent.SendStreamWhisper(user, "/me : [" + ScriptName + "]: You don't  have permission to use this command")
	
	if command in showCommand and (Parent.HasPermission(user, "Moderator", "") or Parent.HasPermission(user, "Everyone", "")):
		if Parent.IsOnUserCooldown(ScriptName, command, user):
			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + " with the following arguments: "+ str(args) +"\n"
			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR: " + user + " tried to display the url in chat with no success. (Reason: "+ user + " had cooldown on command)\n"
			if printLog == True:
				Parent.Log("ERROR: ", "[" + ScriptName + "]: "+ user + " tried to display the url in chat with no success. (Reason: "+ user +" had cooldown on command)")
			Parent.SendStreamWhisper(user, "/me : [" + ScriptName + "]: @" + user + ", " + command + " is under user cooldown for " + str(Parent.GetUserCooldownDuration(ScriptName, command, user)) + " seconds!")
		elif Parent.IsOnCooldown(ScriptName, command):
			Parent.SendStreamWhisper(user, "/me : [" + ScriptName + "]: @" + user + ", " + command + " is under cooldown for " + str(Parent.GetCooldownDuration(ScriptName, command)) + " seconds!")
			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + " with the following arguments: "+ str(args) +"\n"
			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR: " + user + " tried to display the url in chat with no success. (Reason: command had cooldown)\n"
			if printLog == True:
				Parent.Log("ERROR: ", "[" + ScriptName + "]: "+ user + " tried to display the url in chat with no success. (Reason: command had cooldown)")
		elif not (Parent.IsOnCooldown(ScriptName, command) and Parent.IsOnUserCooldown(ScriptName, command, user)):
			if bool(coOn):
				Parent.SendStreamMessage(coMsgToSend)
				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + " to display the Co-Stream url\n"
				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: " + user + " displayed the Co-Stream url in chat\n"
				if printLog == True:
					Parent.Log("INFO:", "[" + ScriptName + "]: "+ user + " displayed the Co-Stream url in chat")
			if not bool(coOn):
				Parent.SendStreamMessage("/me : " + casterName + " is not Co-Streaming right now! Try again later...")
				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "COMMAND: " + command + " used by " + user + " to display the Co-Stream url\n"
				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR: " + user + " failed to display the Co-Stream url in chat. (Reason: No Co-Stream url is created)\n"
				if printLog == True:
					Parent.Log("ERROR:", "[" + ScriptName + "]: " + user + " failed to display the Co-Stream url in chat. (Reason: No Co-Stream url is created)")
		if not Parent.HasPermission(user, "Moderator", ""):
			Parent.AddUserCooldown(ScriptName, command, user, coolDown)
		Parent.AddCooldown(ScriptName, command, globalCD)
	return coMsgToSend

def LogFile():
	global logFileName, logDir, fileSaved, logMessage
	logMessage += "=========\n"
	logMessage += "This is the end of the SettingsLog file\n"
	location = os.path.join(os.getcwd(), logDir)
	try:
		f = open(location + "\\" + logFileName, "w+")
		f.write(logMessage)
		f.close()
		fileSaved = True
		Parent.Log("INFO:", "[" + ScriptName + "]: Log file saved successfully")
	except:
		fileSaved = False
		Parent.Log("ERROR: ", "[" + ScriptName + "]:  Unable to save Log file due to an unexpected error")
	return fileSaved

def SetFriends(names):
	global logMessage, friendsSet, friends
	if names == "":
		logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "ERROR: Unable to retrieve friends. (Reason: Friends list is empty)\n"
		if printLog == True:
			Parent.Log("ERROR:", "[" + ScriptName + "]: Unable to retrieve friends. (Reason: Friends list is empty)")
		friendsSet = False
	else:
		friends = ""
		value = names.split(" ")
		for name in value:
			friends += name + "/"
		logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "INFO: Friends was set to " + str(friends) + "  \n"
		if printLog == True:
			Parent.Log("INFO:", "[" + ScriptName + "]: Friends was set to: " + str(friends))
		friendsSet = True
	return friendsSet

def SetUrl(selProvider):
	global logMessage, urlSet, url, friends, coCustom
	casterName = Parent.GetChannelName()
	casterName = Parent.GetChannelName()
	url = "http://" + selProvider + "/" + casterName.lower() + "/" + friends
	urlSet = True
	return urlSet

def SetGame(game):
	global logMessage, gameToShow, gameSet
	casterName = Parent.GetChannelName()
	if game == "auto" or game == "":
		jsonData = json.loads(Parent.GetRequest("https://decapi.me/twitch/game/" + casterName, {}))
		newGame = jsonData["response"]
		gameToShow = newGame
		gameSet = True
	if game != "" and game != "auto":
		newGame = game
		gameToShow = newGame
		gameSet = True
	return gameSet

#---------------------------------------
# SetDefaults Custom User Interface Button
#---------------------------------------
def ReadMeFile():
    location = os.path.join(os.path.dirname(__file__), "Co-Stream_ReadMe.txt")
    os.startfile(location)

def ChangesFile():
    location = os.path.join(os.path.dirname(__file__), "Co-Stream_Changelog.txt")
    os.startfile(location)

def OpenLogDir():
	location = logDir
	os.startfile(os.path.join(os.getcwd(), location))

def OpenWebSite():
	os.startfile(Website)
