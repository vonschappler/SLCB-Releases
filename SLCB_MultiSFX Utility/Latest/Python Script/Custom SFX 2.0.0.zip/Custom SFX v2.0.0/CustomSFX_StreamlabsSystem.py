#!/usr/bin/env python
# encoding: utf-8

#---------------------------------------
# Import Libraries
#---------------------------------------
import os
import codecs
import json
from collections import OrderedDict as od
from collections import deque
import clr
clr.AddReference("IronPython.SQLite.dll")
clr.AddReference("IronPython.Modules.dll")
import re

#---------------------------------------
# Script Information
#---------------------------------------
ScriptName = "Multi Sound effects"
Website = "https://rebrand.ly/vonWebsite"
Description = "Allows to control multiple sfx with a single command."
Creator = "von_Schappler"
Version = "v2.0.0"

# ---------------------------------------
#	Variables
# ---------------------------------------
global settings, sfxList, sfxQ, triggerList, scriptEnabled, effects, sfxTriggers, installFolder
global username, userid, userInfo
global delay, limitSFX, limitSFXCount, displayNoSFXEntry, noSFXEntryMsg, displayOverLimit, overLimitMsg, displayNoSFX, noSFXMsg, displayNoPoints, noPointsMsg
global isEnabled
settingsFile = ""
sfxFile = ""
settingsFile = os.path.join(os.path.dirname(__file__), "settings.json")
sfxFile = os.path.join(os.path.dirname(__file__), "sfx.json")
isEnabled = True

#---------------------------------------
#   [Required] Initialize Data / Load Only
#---------------------------------------
def Init():
    global settings, sfxList, sfxQ, triggerList, scriptEnabled, effects, sfxTriggers, installFolder
    global username, userid, userInfo
    global delay, limitSFX, limitSFXCount, displayNoSFXEntry, noSFXEntryMsg, displayOverLimit, overLimitMsg, displayNoSFX, noSFXMsg, displayNoPoints, noPointsMsg
    sfxList = []
    sfxQ = deque()
    effects = []
    triggerList = []
    sfxTriggers = []
    userInfo = []
    installFolder = os.getenv("ProgramW6432") + '\dashboard'
    appFolder = os.getenv('AppData') + '\dashboard'
    if os.path.exists(appFolder):
        settingsFile = appFolder + "\\rsc\\settings.json"
        sfxFile = appFolder + "\\rsc\\sfx.json"
    try:
        getSettings(settingsFile)
        delay = float(settings['delay'])
        limitSFX = settings['limitSFX']
        limitSFXCount = int(settings['limitSFXCount'])
        displayNoSFXEntry = settings['displayNoSFXEntry']
        noSFXEntryMsg = settings['noSFXEntryMsg']
        displayOverLimit = settings['displayOverLimit']
        overLimitMsg = settings['overLimitMsg']
        displayNoSFX = settings['displayNoSFX']
        noSFXMsg = settings['noSFXMsg']
        displayNoPoints = settings['displayNoPoints']
        noPointsMsg = settings['noPointsMsg']
        try:
            getSFX(sfxFile)
            for effect in sfxList:
                if effect['sfxEnabled']:
                    effectVolume = int(effect['volume'])*0.01
                    effectMsg = effect['msg']
                    effectTrigger = effect['trigger']
                    effectCost = int(effect['sfxCost'])
                    effectAllowMsg = effect['allowMsg']
                    effectPath = effect['path']
                    info = [effectVolume, effectMsg, effectTrigger, effectCost, effectAllowMsg, effectPath]
                    triggerList.append(effectTrigger)
                    sfxTriggers.append([effectTrigger, effectCost])
                    effects.append(info)
            msg = '/me : [' + ScriptName + " - " + Version + ']: Script was initialized correctly.'
        except:
            msg = '/me : [' + ScriptName + " - " + Version + ']: Unable to read "sfx.json". Please use the dashboard to create or edit this file. "'
    except:
        msg = '/me : [' + ScriptName + " - " + Version + ']: Unable to read "settings.json". Please use the dashboard to create or edit this file.'
    
    SendInfo(Parent.GetChannelName(), msg)
    return

#---------------------------
#   [Optional] Reload Settings (Called when a user clicks the Save Settings button in the Chatbot UI)
#---------------------------
def ReloadSettings():
    Init()
    return

#---------------------------------------
#	Script is going to be unloaded
#---------------------------------------
def Unload():
    return

#---------------------------------------
#	Script is enabled or disabled on UI
#---------------------------------------
def ScriptToggled(state):
    global scriptEnabled
    if not state:
        scriptEnabled = False
        status = 'disabled'
        msg = "/me : [" + ScriptName + " - "+ Version +"] is now {currStatus}".format(currStatus=status)
    else:
        scriptEnabled = True
        status = 'enabled'
        msg = "/me : [" + ScriptName + " - "+ Version +"] is now {currStatus}".format(currStatus=status)
        Init()
	
    SendInfo(Parent.GetChannelName(), msg)
    return

#---------------------------------------
# Execute data and process messages
#---------------------------------------
def Execute(data):
    return

#---------------------------------------
# Tick
#---------------------------------------
def Tick():
    global sfxQ, userInfo
    if sfxQ and not Parent.IsOnCooldown(ScriptName, "delay"):
        Parent.AddCooldown(ScriptName, "delay", float(delay))
        effectVolume = sfxQ[0][0]
        effectMsg = sfxQ[0][1]
        effectTrigger = sfxQ[0][2]
        effectCost = sfxQ[0][3]
        effectAllowMsg = sfxQ[0][4]
        effectPath = sfxQ[0][5]
        if userInfo[2] >= effectCost:
            if Parent.PlaySound(effectPath, effectVolume):
                user = userInfo[0]
                userid = userInfo[1]
                if effectAllowMsg and (effectMsg != ""):
                    Parent.SendStreamMessage(effectMsg)
                Parent.RemovePoints(userid, user, effectCost)
                sfxQ.popleft()
                userInfo[2] = Parent.GetPoints(userInfo[1])
        else:
            if (displayNoPoints == True):
                msg = noPointsMsg.format(user=userInfo[0], sfx=effectTrigger, currency=Parent.GetCurrencyName(), cost=effectCost)
                SendInfo(userInfo[0], msg)
            sfxQ.popleft()
    return

#---------------------------------------
# Functions
#---------------------------------------
def Parse(parseString, userid, username, targetid, targetname, message):
    global userInfo
    regex = re.search(r'\$sfx\((.*)\)', parseString)
    if regex:
        userInfo = []
        userInfo.append(username)
        userInfo.append(userid)
        userInfo.append(Parent.GetPoints(userid))
        RunCommand(regex.group(1), username)
        return parseString.replace(regex.group(0), "")
    return parseString

def RunCommand(cmd, user):
    cmdList = ['play', 'showlist', 'gui', 'restart']
    args = cmd.split(' ')
    toDo = args[0].lower()
    if toDo in cmdList:
        if (toDo == 'gui' and user == Parent.GetChannelName()):
            OpenDashboard()
        if (toDo == 'restart' and user == Parent.GetChannelName()):
            Init()
        if toDo == 'showlist':
            msgToSend = '/me : [' + ScriptName + " - " + Version + ']: Display of possible triggers in the format (name, cost):'
            SendInfo(user, msgToSend)
            msg = SFXListMessage()
            while len(msg) != 0:
                if len(msg) > 0:
                    SendInfo(user, msg[0])
                    msg.pop(0)
                else:
                    msg = []
        if toDo == 'play':
            toPlay = args[1:]
            if (toPlay[0] == ""):
                if displayNoSFXEntry:
                    msg = noSFXEntryMsg.format(user=user)
                    SendInfo(user, msg)
            else:
                if (len(toPlay) > limitSFXCount and limitSFX == True):
                    if displayOverLimit:
                        msg = overLimitMsg.format(user=user, count=str(len(toPlay)), limit=str(limitSFXCount))
                        SendInfo(user, msg)
                else:
                    for effect in toPlay:
                        if (effect in triggerList):
                            index = triggerList.index(effect)
                            sfxQ.append(effects[index])
                        elif (effect not in triggerList) and (displayNoSFX == True):
                            msg = noSFXMsg.format(sfx=effect, user=user)
                            SendInfo(user, msg)
    return

def SFXListMessage():
    global sfxTriggers
    msg = ""
    msgToSend = []
    for sfxTrigger in sfxTriggers:
        msg += "(" + str(sfxTrigger[0]) + ", " + str(sfxTrigger[1]) + "), "
    msg = msg[:-2]
    while len(msg) != 0:
        msgToSend.append(msg[0:500])
        msg = msg[500:]
    return msgToSend

def SendInfo(user, info):
    try:
        Parent.SendStreamWhisper(user, info)
    except:
        Parent.SendStreamMessage(info)
    return

def getSettings(jsondata):
    global settings
    with codecs.open(jsondata, encoding="utf-8-sig", mode="r") as f:
        Parent.Log("JsonData", jsondata)
        settingsData = json.load(f, encoding="utf-8", object_pairs_hook=od)
        Parent.Log("SettingsData", json.dumps(settingsData))
        settings = settingsData
        Parent.Log("Settings", json.dumps(settings))
        Parent.Log("Delay", settings['delay'])
    return settings

def getSFX(jsondata):
    global sfxList
    with codecs.open(jsondata, encoding="utf-8-sig", mode="r") as f:
        sfxData = json.load(f, encoding='latin-1', object_pairs_hook=od)
        sfxList = sfxData['sfx']
    return sfxList

#---------------------------------------
# SetDefaults Custom User Interface Button
#---------------------------------------
def ReadMeFile():
    location = os.path.join(os.path.dirname(__file__), "CustomSFX_ReadMe.txt")
    os.startfile(location)
    return

def ChangesFile():
    location = os.path.join(os.path.dirname(__file__), "CustomSFX_Changelog.txt")
    os.startfile(location)
    return

def OpenWebSite():
    os.startfile(Website)
    return

def OpenDashboard():
    os.startfile(installFolder + '\\dashboard.exe')
    return

def InstallDashboard():
    location = os.path.join(os.path.dirname(__file__), "dashboard Web Setup 1.0.0.exe")
    os.startfile(location)
    return

def Donate():
    PayPal = 'https://rebrand.ly/vonPayPal'
    os.startfile(PayPal)
    return

def JoinDiscord():
    Discord = 'https://rebrand.ly/vonDiscord'
    os.startfile(Discord)
    return