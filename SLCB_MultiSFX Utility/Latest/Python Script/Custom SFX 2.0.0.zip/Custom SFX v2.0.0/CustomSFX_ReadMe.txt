IMPORTANT INFORMATION:

    Before proceeding to use this script and the external tool provided with it (the dashboard), read the content of this file.
        1. Before going ahead, do not remove or disable the previous versions of this script, until everything is set up, tested and working as intended.
        2. Details about the base script settings needed to connect with the dashboard will be provided on the dashboard Documentation Viewer window.
        3. After reading this, proceed to the use of the dashboard.
    
    1. Directory Structure:
        After importing the provided script to your Streamlabs Chatbot the directory and files structure should contains the following files:
         - CommandList.abcomg:
           Chat commands to be imported to Streamlabs Chatbot. Those commands can be customized after the import (specific details on this customization will be given later in this file).
         - CustomSFX_ReadMe.txt:
           This file.
         - CustomSFX_StreamlabsSystem.py:
           The base script that runs inside Streamlabs Chatbot, responsible to connect the dashboard to it and execute routines necessary to play the sound effects.
         - dashboard Web Setup 1.0.0.exe:
           One-click executable file to install the dashboard. Updated versions of the script pack may have a different version of this file.
         - UI_Config.json:
           Streamlabs Chatbot script UI configuration.
    
    2. Streamlabs Chatbot script UI and starting settings:
    
        Since the customization of the script is controlled by the dashboard, the Streamlabs Chatbot script UI is formed simply by buttons.
            Group 1:
            - READ THIS BEFORE CONTINUE
            Opens this file. As stated before, the file is simply a text version of the this section presented in the dashboard Documentation Viewer (with sigtly modifications to fit its purpose).
            
            Group 2: Dashboard Controller Settings
            - INSTALL DASHBOARD
            Installs the dasboard application to control the script settings. The installer is a one-click installable version, which installs the application in a default location(c:\Program Files\dashboard), with an optional button to start it right after the instalation, as a stand-alone application. It's possible to run the installation outside of the chatbot, but it will require UAC rights to proceed with the installation. It's highly advisable to run it from within the chatbot.
            This step is required in order to proceed using the script.
            - OPEN DASHBOARD
            Opens the [Custom SFX v2.0.0] - Dashboard application. As stated before, the dashboard can be run as a stand-alone application. If you wish to run the dashboard as a stand-alone application, UAC rights will be required, so it's also righly advisable to run it from within the chatbot. Once the dashboard is opened, it's possible to operate with it, by clicking on any of the buttons displayed on the starting interface.
            
            Group 3: Support
            - DONATE THIS PROJECT
            Opens your default browser with a link to von Schappler's Paypal Page, where you can donate for this and other projects in progress. This a non-required donation, but much appreciated IF you can donate.
            - VISIT MY SITE
            Opens your default browser with a link to visit von Schappler's Website.
            - SUPPORT
            Opens your default browser with a link to join von Schappler's Discord Server, where all the support is provided. In order to ask for support, it's required to join the server and self-assing the necessary roles for that. 
            - Save Settings
            This button has no use in this script.
        
        After this quick view on the script UI, it's time to explain the starting settings required inside chatbot so evertyhing can run as expected. This file will not cover Streamlabs Chatbot functionalities in detail, so if you can't follow any of the steps below, check the chatbot documentation by clicking the Help button on the top-right corner of the chatbot.
        
        Step 01: Importing the script commands
        - Open the Commands tab on the chatbot
        - Click the Import button
        - Select the file CommandList.abcomg provided inside the script pack, located inside the script install directory.
        If you are unsure of the file location, you can find it by clicking Help button and selecting the option "Open Script Directory"". The file is located on "%StreamlabsChatbotScriptsDir%\CustomSFX v2.0.0" directory.
        - If a Warning window pops up, click Yes
        This will overwrite previous versions of this command in order to make them work with the new version of the script.
        
        After following those steps, the list of commands for this script will be loaded on your Commands tab.
        
        Step 02: Understading the commands and customizing them
        The commands have default triggers to be used when they are imported. Here is a quick explanation of what they do:
        
            !sfx <trigger_1, trigger_2, ..., trigger_n>
            This command will trigger the created sound effects using this dashboard. At least one trigger is required for this command to work and the number of sequential triggers can be limited in the settings created with the dashboard.
            - Command response:
                The command will:
                    a) Trigger the sound effects in the order they were requested to be played; or 
                    b) Notify the user of the command (either in chat or on the user whisper) that one or more triggers can't be used and why, as long as this option is configured properly on the script settings section of the dashboard
            
            !sfxgui
            This command, usded only by the caster, will open the dashboard application, without the need of leaving the console tab inside the chatbot.
            - Command response:
                None
            
            !sfxlist
            This command will send a chat message with the list of created sound effects.
            - Command response:
                The list of usable triggers will be sent either in chat or in the user whisper, in the order they were created in the dashboard, followed by their indivudual cost.
            
            !sfxrestart
            This command will restart the script, reading all resource files created with the dashboard and making the script ready for use.
            - Command response:
                None
        
        
            IMPORTANT:
            Keep in mind that from this point, whenever you see "either in chat or on the user whisper", this means that the script will try to send any message to the user whisper before sending on chat.
            This is a preventive measure to avoid chat spam that may be caused by the bot, in case of a huge sound effects list.
        
        To edit any of those commands, click on Edit button, after selecting the command you wish to edit. If you wish to edit the commands, keep in mind that ONLY the triggers can be changed. Any changes in the Response field may prevent the command from working properly.
        
        Step 03: Adding new commands (optional)
        Let's suppose, for illustration purpose, that one specific command is used more than the others, or that you want to make a "quick trigger" for a specific sound effect. This is totally possible to be done, by creating a new command (clicking the Add button on the commands tab inside chatbot). In order to do so, proceed as followed:
        - Create the new command as any other
        - In the response field, the script parameter has to be added, as described below:
        
            $sfx(play <triggers>), where triggers have to be replaced by the trigger (or triggers) to be played with the new created command
            Example of working response:
            $sfx(play effect1 effect2)
        
        The newly created command will trigger both effects (effect1 and effect2) when used in chat.
        
            IMPORTANT:
            The Step 03, if opted to be executed, must be done ONLY after at least one custom effect is created on the dashboard, since the parameter inside the argument "$sfx()" must be existent sound effects.
        
        Step 04: Export commands to Streamlabs page (optional)
        If you have your chatbot linked to your Streamlabs tip page, it's possible to export the commands to there. In order to know more about this feature, check the Streamlabs Chatbot documentation.

    You are now all set and ready to use the Dashboard!